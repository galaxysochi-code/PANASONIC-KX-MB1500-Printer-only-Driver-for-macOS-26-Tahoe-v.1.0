#!/bin/bash
# Сборка установочного пакета «Panasonic MFP.pkg».
#
# В пакете только собственный код: приложение, бэкенд CUPS, описание принтера
# и описание контейнера. Драйвер Panasonic не распространяется — он скачивается
# с сайта производителя при первом запуске и проверяется по контрольной сумме.
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION="${VERSION:-1.0}"
IDENTIFIER="com.vt.panasonicmfp.installer"
PKG_NAME="Panasonic MFP ${VERSION}.pkg"
ROOT="build/pkgroot"
SCRIPTS="build/pkgscripts"
INSTALL_DIR="$ROOT/Library/Printers/PanasonicMFP"

die() { echo "Ошибка: $*" >&2; exit 1; }

echo "==> Сборка приложения"
./build.sh release >/dev/null
[ -d "build/Panasonic MFP.app" ] || die "приложение не собралось"

echo "==> Подготовка содержимого пакета"
rm -rf "$ROOT" "$SCRIPTS"
mkdir -p "$ROOT/Applications" "$INSTALL_DIR/driver" "$INSTALL_DIR/scanner" \
         "$ROOT/usr/libexec/cups/backend" "$SCRIPTS"

cp -R "build/Panasonic MFP.app" "$ROOT/Applications/"

install -m 755 macos/panasonic-mfp-service    "$INSTALL_DIR/panasonic-mfp-service"
install -m 755 macos/panasonic-mfp-supervisor "$INSTALL_DIR/panasonic-mfp-supervisor"
install -m 644 macos/PanasonicKXMB1500.ppd    "$INSTALL_DIR/PanasonicKXMB1500.ppd"
install -m 700 macos/panasonic-mfp-backend    "$ROOT/usr/libexec/cups/backend/panasonic"

install -m 644 driver/Dockerfile "$INSTALL_DIR/driver/Dockerfile"
install -m 755 driver/server.py  "$INSTALL_DIR/driver/server.py"

# Сканирование: мост между USB и контейнером плюс описание самого контейнера.
# Драйвер сканера, как и драйвер печати, скачивается при первом обращении.
echo "==> Сборка USB-моста"
swiftc -O scanner/usbbridge.swift -o build/usbbridge
install -m 755 build/usbbridge       "$INSTALL_DIR/usbbridge"
install -m 644 scanner/Dockerfile    "$INSTALL_DIR/scanner/Dockerfile"
install -m 644 scanner/libusb-shim.c "$INSTALL_DIR/scanner/libusb-shim.c"
install -m 644 scanner/sane-compat.c "$INSTALL_DIR/scanner/sane-compat.c"

install -m 755 packaging/postinstall "$SCRIPTS/postinstall"

echo "==> Сборка pkg"
pkgbuild --root "$ROOT" \
         --scripts "$SCRIPTS" \
         --identifier "$IDENTIFIER" \
         --version "$VERSION" \
         --ownership recommended \
         --install-location / \
         "build/component.pkg" >/dev/null

cat > build/distribution.xml <<XML_END
<?xml version="1.0" encoding="utf-8"?>
<installer-gui-script minSpecVersion="2">
    <title>Panasonic KX-MB1500</title>
    <organization>com.vt</organization>
    <options customize="never" require-scripts="true" hostArchitectures="arm64,x86_64"/>
    <volume-check>
        <allowed-os-versions><os-version min="15.0"/></allowed-os-versions>
    </volume-check>
    <welcome file="welcome.txt"/>
    <choices-outline><line choice="default"/></choices-outline>
    <choice id="default" title="Panasonic MFP">
        <pkg-ref id="${IDENTIFIER}"/>
    </choice>
    <pkg-ref id="${IDENTIFIER}" version="${VERSION}" onConclusion="none">component.pkg</pkg-ref>
</installer-gui-script>
XML_END

cat > build/welcome.txt <<'TXT_END'
Драйвер и приложение для МФУ Panasonic KX-MB1500 на macOS 15 и новее.

Будет установлено:
  • приложение «Panasonic MFP» в папку «Программы» — печать и сканирование;
  • системный принтер «Panasonic KX-MB1500» — он появится в диалоге
    печати любой программы: Word, «Просмотр», Safari;
  • служебные компоненты драйвера, включая USB-мост для сканера.

ЧТО НУЖНО ЗАРАНЕЕ

Родные драйверы Panasonic существуют только для Linux и работают
в контейнере. Для него потребуются colima и docker:

    brew install colima docker

При первом запуске приложение само скачает драйверы с сайта поддержки
Panasonic и соберёт контейнеры. Нужен доступ в интернет; первая сборка
занимает несколько минут.

Сканер не появится в «Захвате изображений» и других программах macOS:
родной модуль Panasonic на современных системах не работает. Сканирование
доступно в приложении «Panasonic MFP».
TXT_END

productbuild --distribution build/distribution.xml \
             --resources build \
             --package-path build \
             "build/${PKG_NAME}" >/dev/null

rm -f build/component.pkg build/distribution.xml build/welcome.txt
rm -rf "$ROOT" "$SCRIPTS"

# Собранный бандл в каталоге сборки не оставляем.
#
# LaunchServices заносит в свою базу каждое приложение, которое видит на диске,
# и «Приложения» показывают ДВА «Panasonic MFP»: настоящий из /Applications и
# этот. Файл .metadata_never_index здесь не помогает — он закрывает каталог от
# Spotlight, а LaunchServices ведёт учёт сам по себе. Внутри сборки бандл нужен
# только чтобы попасть в пакет, дальше он лишний.
rm -rf "build/Panasonic MFP.app"

echo
echo "Готово: $(pwd)/build/${PKG_NAME}"
du -h "build/${PKG_NAME}" | awk '{print "Размер: " $1}'
