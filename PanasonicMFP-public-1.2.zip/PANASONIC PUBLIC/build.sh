#!/bin/bash
# Сборка .app-бандла для macOS (arm64).
set -euo pipefail
cd "$(dirname "$0")"

CONFIG="${1:-release}"
APP_NAME="Panasonic MFP"
BUNDLE="build/${APP_NAME}.app"

echo "==> swift build (${CONFIG})"
swift build -c "${CONFIG}" --arch arm64

BIN_DIR="$(swift build -c "${CONFIG}" --arch arm64 --show-bin-path)"
BIN="${BIN_DIR}/PanasonicMFP"
[ -x "${BIN}" ] || { echo "Не найден исполняемый файл: ${BIN}"; exit 1; }

echo "==> сборка бандла"
rm -rf "${BUNDLE}"
mkdir -p "${BUNDLE}/Contents/MacOS" "${BUNDLE}/Contents/Resources"
cp "${BIN}" "${BUNDLE}/Contents/MacOS/PanasonicMFP"
cp Resources/Info.plist "${BUNDLE}/Contents/Info.plist"
printf 'APPL????' > "${BUNDLE}/Contents/PkgInfo"
[ -f Resources/AppIcon.icns ] && cp Resources/AppIcon.icns "${BUNDLE}/Contents/Resources/AppIcon.icns"

# Локализации: интерфейс следует языку системы (русский и английский).
for lproj in Resources/*.lproj; do
    [ -d "${lproj}" ] || continue
    cp -R "${lproj}" "${BUNDLE}/Contents/Resources/"
done

echo "==> подпись (ad-hoc)"
codesign --force --sign - --identifier com.vt.panasonicmfp "${BUNDLE}" >/dev/null

# USB-мост для сканирования: приложение запускает его как отдельную программу.
# При запуске из исходников оно ищет мост здесь же, в build/.
echo "==> USB-мост"
swiftc -O scanner/usbbridge.swift -o build/usbbridge

echo "Готово: ${PWD}/${BUNDLE}"
