# Installation Guide

Step-by-step setup of the Panasonic KX-MB1500 driver on macOS 15 or newer,
Apple Silicon or Intel.

Plan on 15–20 minutes for the first run, most of which is unattended: the
vendor driver is downloaded and a container image is built on your machine.

---

## 1. Before you start

You need three things.

**A supported macOS.** 15 or newer. The package refuses to install on older
systems.

**Homebrew.** If you do not have it, follow the instructions at
[brew.sh](https://brew.sh).

**colima and docker.** The Panasonic driver exists only for Linux, so it runs
inside a container. Install both:

```bash
brew install colima docker
```

You do not need Docker Desktop, and you do not need a Docker account. colima is
a small VM manager; on Apple Silicon it runs the x86-64 vendor driver through
Rosetta.

---

## 2. Install the package

Download `Panasonic MFP <version>.pkg` from Releases and open it.

The package is not signed by a registered Apple developer, so Gatekeeper will
block the first attempt. Either right-click the file and choose **Open**, or go
to *System Settings → Privacy & Security* and allow it there.

The installer places the application, a CUPS backend, the service scripts and
the container definitions, then creates the print queue. It does not download
anything at this stage.

---

## 3. First launch

Connect the printer with a USB cable and switch it on.

Open **Panasonic MFP** from Applications. On the first launch it:

1. downloads the Panasonic driver from the vendor's official support site and
   verifies its SHA-256 checksum;
2. builds the container image.

This needs internet access and takes a few minutes. The **Print** tab shows the
service state; wait until it reads that the service is running.

---

## 4. Verify

Print any document from Preview or Word and pick **Panasonic KX-MB1500** in the
print dialog. The application does not need to be running for this — a
background helper keeps the conversion service alive.

If a sheet comes out, you are done.

To check scanning, open the **Scan** tab and scan a page. The first scan
downloads the scanner driver and builds a second container, so it takes a few
minutes once.

---

## 5. If something goes wrong

**Nothing prints and the queue looks stuck.** The most reliable reset is to
restart the printing system:

```bash
sudo launchctl kickstart -k system/org.cups.cupsd
```

**The service is not running.** Manage it directly:

```bash
/Library/Printers/PanasonicMFP/panasonic-mfp-service status
/Library/Printers/PanasonicMFP/panasonic-mfp-service start
/Library/Printers/PanasonicMFP/panasonic-mfp-service logs
```

**Only the first document prints when you select several files at once.** This
is a known limitation, not a misconfiguration — see *Known limitations* in the
[README](../README.md). Print the files one at a time, or add them in the
application, which sends them as separate jobs.

**The scanner is missing from Image Capture.** Expected: the vendor's ICA
module does not load on current macOS. Scanning works only inside the
application.

**The printer disappears from the USB bus.** The device drops off the bus when
it sleeps. Press any button on it, wait a few seconds, then retry.

---

## 6. Uninstall

```bash
lpadmin -x Panasonic_KX_MB1500
launchctl bootout gui/$UID/com.vt.panasonic-mfp.supervisor
rm -f ~/Library/LaunchAgents/com.vt.panasonic-mfp.supervisor.plist
/Library/Printers/PanasonicMFP/panasonic-mfp-service stop
sudo rm -rf /Library/Printers/PanasonicMFP /usr/libexec/cups/backend/panasonic
sudo rm -rf "/Applications/Panasonic MFP.app"
rm -rf ~/Library/Application\ Support/PanasonicMFP
docker rmi panasonic-mfp-converter panasonic-mfp-scanner
```

colima and docker are left in place — remove them with `brew uninstall` if you
installed them only for this.
