// USB-мост для сканера Panasonic KX-MB1500.
//
// Родной драйвер сканера Panasonic существует только для Linux и работает
// в контейнере, а контейнер на macOS не имеет доступа к USB. Мост закрывает
// этот разрыв: он держит устройство открытым через IOKit и выполняет запросы,
// приходящие по локальному соединению от прослойки libusb внутри контейнера.
//
// Протокол намеренно примитивен — ровно то, что нужно libusb-0.1:
//   запрос:  [код операции: 1][длина полезной части: 4][полезная часть]
//   ответ:   [состояние: 4 со знаком][длина: 4][данные]
// Отрицательное состояние — ошибка, для чтения оно равно числу принятых байтов.
//
// Сборка: swiftc -O scanner/usbbridge.swift -o build/usbbridge

import Foundation
import IOKit
import IOKit.usb
import IOUSBHost
import Network

let vendorID = 0x04DA
let productID = 0x0F0B
let listenPort: UInt16 = 9632

// MARK: - Коды операций

enum Op: UInt8 {
    case descriptors     = 0x01
    case open            = 0x02
    case close           = 0x03
    case claim           = 0x04
    case release         = 0x05
    case setConfig       = 0x06
    case setAltInterface = 0x07
    case clearHalt       = 0x08
    case control         = 0x09
    case bulkRead        = 0x0A
    case bulkWrite       = 0x0B
    case interruptRead   = 0x0C
}

enum BridgeError: Int32 {
    case notFound   = -1
    case notOpen    = -2
    case ioFailed   = -5
    case badRequest = -22
}

// MARK: - Работа с устройством

final class USBDevice {
    private var device: IOUSBHostDevice?
    private var interfaces: [Int: IOUSBHostInterface] = [:]
    private var pipes: [Int: IOUSBHostPipe] = [:]

    private func service(matching className: String, filter: (io_object_t) -> Bool) -> io_object_t? {
        guard let matching = IOServiceMatching(className) else { return nil }
        var iterator: io_iterator_t = 0
        guard IOServiceGetMatchingServices(kIOMainPortDefault, matching, &iterator) == KERN_SUCCESS else {
            return nil
        }
        defer { IOObjectRelease(iterator) }
        var found: io_object_t?
        while case let candidate = IOIteratorNext(iterator), candidate != 0 {
            if found == nil, filter(candidate) { found = candidate } else { IOObjectRelease(candidate) }
        }
        return found
    }

    private func number(_ service: io_object_t, _ key: String) -> Int? {
        guard let value = IORegistryEntryCreateCFProperty(service, key as CFString, kCFAllocatorDefault, 0)
        else { return nil }
        return (value.takeRetainedValue() as? NSNumber)?.intValue
    }

    private func isOurDevice(_ service: io_object_t) -> Bool {
        number(service, "idVendor") == vendorID && number(service, "idProduct") == productID
    }

    func open() throws {
        if device != nil { return }
        guard let deviceService = service(matching: "IOUSBHostDevice", filter: { self.isOurDevice($0) }) else {
            throw NSError(domain: "bridge", code: Int(BridgeError.notFound.rawValue))
        }
        defer { IOObjectRelease(deviceService) }
        device = try IOUSBHostDevice(__ioService: deviceService, options: [], queue: nil, interestHandler: nil)
        log("устройство открыто")
    }

    func close() {
        pipes.removeAll()
        interfaces.values.forEach { $0.destroy() }
        interfaces.removeAll()
        device?.destroy()
        device = nil
        log("устройство закрыто")
    }

    /// Дескриптор устройства и полный дескриптор конфигурации — из них
    /// прослойка собирает структуры, которых ждёт libusb.
    func descriptors() throws -> Data {
        guard let device else { throw NSError(domain: "bridge", code: Int(BridgeError.notOpen.rawValue)) }
        var result = Data()

        if let descriptor = device.deviceDescriptor {
            withUnsafeBytes(of: descriptor.pointee) { result.append(contentsOf: $0) }
        }
        let deviceLength = result.count

        if let configuration = device.configurationDescriptor {
            let total = Int(configuration.pointee.wTotalLength)
            configuration.withMemoryRebound(to: UInt8.self, capacity: total) { pointer in
                result.append(pointer, count: total)
            }
        }

        // Впереди — длина дескриптора устройства, чтобы прослойка знала границу.
        var header = UInt16(deviceLength).littleEndian
        var framed = Data(bytes: &header, count: 2)
        framed.append(result)
        return framed
    }

    func claim(interfaceNumber: Int) throws {
        guard device != nil else { throw NSError(domain: "bridge", code: Int(BridgeError.notOpen.rawValue)) }
        if interfaces[interfaceNumber] != nil { return }

        guard let interfaceService = service(matching: "IOUSBHostInterface", filter: {
            self.isOurDevice($0) && self.number($0, "bInterfaceNumber") == interfaceNumber
        }) else {
            throw NSError(domain: "bridge", code: Int(BridgeError.notFound.rawValue))
        }
        defer { IOObjectRelease(interfaceService) }

        interfaces[interfaceNumber] = try IOUSBHostInterface(__ioService: interfaceService,
                                                             options: [], queue: nil, interestHandler: nil)
        log("интерфейс \(interfaceNumber) захвачен")
    }

    func release(interfaceNumber: Int) {
        pipes = pipes.filter { _, _ in true }
        interfaces[interfaceNumber]?.destroy()
        interfaces.removeValue(forKey: interfaceNumber)
    }

    private func pipe(for endpoint: Int) throws -> IOUSBHostPipe {
        if let existing = pipes[endpoint] { return existing }
        for interface in interfaces.values {
            if let found = try? interface.copyPipe(withAddress: endpoint) {
                pipes[endpoint] = found
                return found
            }
        }
        throw NSError(domain: "bridge", code: Int(BridgeError.notFound.rawValue))
    }

    func clearHalt(endpoint: Int) throws {
        try pipe(for: endpoint).clearStall()
    }

    func control(requestType: UInt8, request: UInt8, value: UInt16, index: UInt16,
                 length: UInt16, timeout: UInt32, outgoing: Data) throws -> Data {
        guard let device else { throw NSError(domain: "bridge", code: Int(BridgeError.notOpen.rawValue)) }

        var deviceRequest = IOUSBDeviceRequest(bmRequestType: requestType,
                                               bRequest: request,
                                               wValue: value,
                                               wIndex: index,
                                               wLength: length)
        let isInput = (requestType & 0x80) != 0
        let buffer = NSMutableData(length: Int(length)) ?? NSMutableData()
        if !isInput, !outgoing.isEmpty {
            buffer.replaceBytes(in: NSRange(location: 0, length: min(outgoing.count, Int(length))),
                                withBytes: [UInt8](outgoing))
        }

        var transferred: UInt = 0
        try device.__send(deviceRequest,
                          data: length > 0 ? buffer : nil,
                          bytesTransferred: &transferred,
                          completionTimeout: TimeInterval(timeout) / 1000.0)
        guard isInput, transferred > 0 else { return Data() }
        return Data(bytes: buffer.bytes, count: min(Int(transferred), Int(length)))
    }

    func bulkRead(endpoint: Int, length: Int, timeout: UInt32) throws -> Data {
        let buffer = NSMutableData(length: length) ?? NSMutableData()
        var transferred: UInt = 0
        try pipe(for: endpoint).__sendIORequest(with: buffer,
                                                bytesTransferred: &transferred,
                                                completionTimeout: TimeInterval(timeout) / 1000.0)
        return Data(bytes: buffer.bytes, count: min(Int(transferred), length))
    }

    @discardableResult
    func bulkWrite(endpoint: Int, payload: Data, timeout: UInt32) throws -> Int {
        let buffer = NSMutableData(data: payload)
        var transferred: UInt = 0
        try pipe(for: endpoint).__sendIORequest(with: buffer,
                                                bytesTransferred: &transferred,
                                                completionTimeout: TimeInterval(timeout) / 1000.0)
        return Int(transferred)
    }
}

// MARK: - Журнал

let logQueue = DispatchQueue(label: "bridge.log")
func log(_ message: String) {
    logQueue.async {
        FileHandle.standardError.write("[usbbridge] \(message)\n".data(using: .utf8)!)
    }
}

// MARK: - Разбор запросов

let usb = USBDevice()
let deviceQueue = DispatchQueue(label: "bridge.device")

func handle(op: Op, payload: Data) -> (Int32, Data) {
    func u8(_ offset: Int) -> UInt8 { payload[payload.startIndex + offset] }
    func u16(_ offset: Int) -> UInt16 {
        UInt16(u8(offset)) | (UInt16(u8(offset + 1)) << 8)
    }
    func u32(_ offset: Int) -> UInt32 {
        UInt32(u8(offset)) | (UInt32(u8(offset + 1)) << 8)
            | (UInt32(u8(offset + 2)) << 16) | (UInt32(u8(offset + 3)) << 24)
    }

    do {
        switch op {
        case .open:
            try usb.open(); return (0, Data())
        case .close:
            usb.close(); return (0, Data())
        case .descriptors:
            let data = try usb.descriptors(); return (Int32(data.count), data)
        case .claim:
            guard payload.count >= 1 else { return (BridgeError.badRequest.rawValue, Data()) }
            try usb.claim(interfaceNumber: Int(u8(0))); return (0, Data())
        case .release:
            guard payload.count >= 1 else { return (BridgeError.badRequest.rawValue, Data()) }
            usb.release(interfaceNumber: Int(u8(0))); return (0, Data())
        case .setConfig, .setAltInterface:
            // Конфигурация и альтернативная настройка выбираются системой при
            // захвате интерфейса; отдельного действия не требуется.
            return (0, Data())
        case .clearHalt:
            guard payload.count >= 1 else { return (BridgeError.badRequest.rawValue, Data()) }
            try usb.clearHalt(endpoint: Int(u8(0))); return (0, Data())
        case .control:
            guard payload.count >= 13 else { return (BridgeError.badRequest.rawValue, Data()) }
            let outgoing = payload.count > 13 ? payload.suffix(from: payload.startIndex + 13) : Data()
            let data = try usb.control(requestType: u8(0), request: u8(1),
                                       value: u16(2), index: u16(4), length: u16(6),
                                       timeout: u32(8), outgoing: Data(outgoing))
            return (Int32(data.count), data)
        case .bulkRead, .interruptRead:
            guard payload.count >= 9 else { return (BridgeError.badRequest.rawValue, Data()) }
            let data = try usb.bulkRead(endpoint: Int(u8(0)), length: Int(u32(1)), timeout: u32(5))
            return (Int32(data.count), data)
        case .bulkWrite:
            guard payload.count >= 5 else { return (BridgeError.badRequest.rawValue, Data()) }
            let body = payload.count > 5 ? Data(payload.suffix(from: payload.startIndex + 5)) : Data()
            let sent = try usb.bulkWrite(endpoint: Int(u8(0)), payload: body, timeout: u32(1))
            return (Int32(sent), Data())
        }
    } catch let error as NSError {
        log("операция \(op) — ошибка: \(error.localizedDescription)")
        let code = Int32(error.code)
        return (code < 0 ? code : BridgeError.ioFailed.rawValue, Data())
    }
}

// MARK: - Сервер

func serve(connection: FileHandle) {
    defer { try? connection.close() }

    func readExactly(_ count: Int) -> Data? {
        var buffer = Data()
        while buffer.count < count {
            guard let chunk = try? connection.read(upToCount: count - buffer.count), !chunk.isEmpty
            else { return nil }
            buffer.append(chunk)
        }
        return buffer
    }

    while true {
        guard let header = readExactly(5) else { return }
        let opcode = header[0]
        let length = Int(UInt32(header[1]) | (UInt32(header[2]) << 8)
                         | (UInt32(header[3]) << 16) | (UInt32(header[4]) << 24))
        let payload = length > 0 ? (readExactly(length) ?? Data()) : Data()

        guard let op = Op(rawValue: opcode) else {
            log("неизвестная операция \(opcode)")
            return
        }

        let (status, data) = deviceQueue.sync { handle(op: op, payload: payload) }

        var response = Data()
        withUnsafeBytes(of: status.littleEndian) { response.append(contentsOf: $0) }
        withUnsafeBytes(of: UInt32(data.count).littleEndian) { response.append(contentsOf: $0) }
        response.append(data)
        connection.write(response)
    }
}

// Простой TCP-сервер на BSD-сокетах: Network.framework здесь избыточен.
let listenSocket = socket(AF_INET, SOCK_STREAM, 0)
guard listenSocket >= 0 else { log("не удалось создать сокет"); exit(1) }
var reuse: Int32 = 1
setsockopt(listenSocket, SOL_SOCKET, SO_REUSEADDR, &reuse, socklen_t(MemoryLayout<Int32>.size))

var address = sockaddr_in()
address.sin_family = sa_family_t(AF_INET)
address.sin_port = listenPort.bigEndian
address.sin_addr.s_addr = INADDR_ANY          // контейнер обращается снаружи петли
address.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)

let bindResult = withUnsafePointer(to: &address) {
    $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {
        bind(listenSocket, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
    }
}
guard bindResult == 0 else { log("порт \(listenPort) занят"); exit(1) }
guard listen(listenSocket, 4) == 0 else { log("listen не удался"); exit(1) }

log("мост запущен на порту \(listenPort)")

while true {
    let client = accept(listenSocket, nil, nil)
    guard client >= 0 else { continue }
    let handle = FileHandle(fileDescriptor: client, closeOnDealloc: true)
    DispatchQueue.global().async { serve(connection: handle) }
}
