/*
 * Подмена libusb-0.1 для контейнера со сканером Panasonic.
 *
 * Драйвер Panasonic для Linux обращается к USB через libusb-0.1, но USB
 * в контейнере на macOS недоступен. Эта библиотека повторяет интерфейс
 * libusb-0.1 и переадресует все вызовы мосту, работающему на стороне macOS.
 * Драйвер об этом не знает и считает, что говорит с устройством напрямую.
 *
 * Адрес моста задаётся переменной PANASONIC_BRIDGE (по умолчанию
 * host.docker.internal:9632).
 *
 * Сборка (внутри контейнера):
 *   gcc -shared -fPIC -O2 -o libusb-0.1.so.4 libusb-shim.c
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <arpa/inet.h>
#include <netdb.h>

/*
 * Именно 4097, а не 512, как в libusb-0.1.12. Бэкенд Panasonic собран со
 * старым заголовком libusb, где LIBUSB_PATH_MAX = PATH_MAX + 1, и это видно
 * по отладочной информации самой библиотеки: поле usb_bus.devices лежит по
 * смещению 0x1018. Разойдись мы здесь — бэкенд читает список устройств за
 * концом наших структур и молча не находит ничего.
 */
#define LIBUSB_PATH_MAX 4097

/* ---- Структуры libusb-0.1: разметка обязана совпадать байт в байт ---- */

struct usb_device_descriptor {
    uint8_t  bLength, bDescriptorType;
    uint16_t bcdUSB;
    uint8_t  bDeviceClass, bDeviceSubClass, bDeviceProtocol, bMaxPacketSize0;
    uint16_t idVendor, idProduct, bcdDevice;
    uint8_t  iManufacturer, iProduct, iSerialNumber, bNumConfigurations;
};

struct usb_endpoint_descriptor {
    uint8_t  bLength, bDescriptorType, bEndpointAddress, bmAttributes;
    uint16_t wMaxPacketSize;
    uint8_t  bInterval, bRefresh, bSynchAddress;
    unsigned char *extra;
    int extralen;
};

struct usb_interface_descriptor {
    uint8_t bLength, bDescriptorType, bInterfaceNumber, bAlternateSetting;
    uint8_t bNumEndpoints, bInterfaceClass, bInterfaceSubClass, bInterfaceProtocol, iInterface;
    struct usb_endpoint_descriptor *endpoint;
    unsigned char *extra;
    int extralen;
};

struct usb_interface {
    struct usb_interface_descriptor *altsetting;
    int num_altsetting;
};

struct usb_config_descriptor {
    uint8_t  bLength, bDescriptorType;
    uint16_t wTotalLength;
    uint8_t  bNumInterfaces, bConfigurationValue, iConfiguration, bmAttributes, MaxPower;
    struct usb_interface *interface;
    unsigned char *extra;
    int extralen;
};

struct usb_bus;

struct usb_device {
    struct usb_device *next, *prev;
    char filename[LIBUSB_PATH_MAX];
    struct usb_bus *bus;
    struct usb_device_descriptor descriptor;
    struct usb_config_descriptor *config;
    void *dev;
    uint8_t devnum;
    unsigned char num_children;
    struct usb_device **children;
};

struct usb_bus {
    struct usb_bus *next, *prev;
    char dirname[LIBUSB_PATH_MAX];
    struct usb_device *devices;
    uint32_t location;
    struct usb_device *root_dev;
};

typedef struct usb_dev_handle usb_dev_handle;

/* ---- Коды операций моста ---- */

enum {
    OP_DESCRIPTORS = 0x01, OP_OPEN = 0x02, OP_CLOSE = 0x03,
    OP_CLAIM = 0x04, OP_RELEASE = 0x05, OP_SET_CONFIG = 0x06,
    OP_SET_ALTIFACE = 0x07, OP_CLEAR_HALT = 0x08, OP_CONTROL = 0x09,
    OP_BULK_READ = 0x0A, OP_BULK_WRITE = 0x0B, OP_INTERRUPT_READ = 0x0C
};

static int bridge_fd = -1;
static char last_error[256] = "";
static int debug_level = 0;

static struct usb_bus *bus_list = NULL;
static struct usb_device *the_device = NULL;

#define TRACE(...) do { if (debug_level > 0) { \
    fprintf(stderr, "[libusb-shim] "); fprintf(stderr, __VA_ARGS__); fputc('\n', stderr); } } while (0)

/* ---- Связь с мостом ---- */

static int bridge_connect(void)
{
    if (bridge_fd >= 0) return 0;

    const char *spec = getenv("PANASONIC_BRIDGE");
    char host[128] = "host.docker.internal";
    int port = 9632;
    if (spec && *spec) {
        const char *colon = strrchr(spec, ':');
        if (colon) {
            size_t len = (size_t)(colon - spec);
            if (len >= sizeof(host)) len = sizeof(host) - 1;
            memcpy(host, spec, len); host[len] = '\0';
            port = atoi(colon + 1);
        } else {
            snprintf(host, sizeof(host), "%s", spec);
        }
    }

    char service[16];
    snprintf(service, sizeof(service), "%d", port);

    struct addrinfo hints, *result = NULL;
    memset(&hints, 0, sizeof(hints));
    hints.ai_family = AF_INET;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, service, &hints, &result) != 0 || !result) {
        snprintf(last_error, sizeof(last_error), "не удалось разрешить имя моста %s", host);
        return -1;
    }

    int fd = socket(result->ai_family, result->ai_socktype, 0);
    if (fd < 0 || connect(fd, result->ai_addr, result->ai_addrlen) != 0) {
        if (fd >= 0) close(fd);
        freeaddrinfo(result);
        snprintf(last_error, sizeof(last_error), "мост недоступен на %s:%d", host, port);
        return -1;
    }
    freeaddrinfo(result);

    int one = 1;
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    bridge_fd = fd;
    TRACE("подключён к мосту %s:%d", host, port);
    return 0;
}

static int write_all(int fd, const void *data, size_t length)
{
    const unsigned char *pointer = data;
    while (length > 0) {
        ssize_t written = write(fd, pointer, length);
        if (written <= 0) return -1;
        pointer += written; length -= (size_t)written;
    }
    return 0;
}

static int read_all(int fd, void *data, size_t length)
{
    unsigned char *pointer = data;
    while (length > 0) {
        ssize_t got = read(fd, pointer, length);
        if (got <= 0) return -1;
        pointer += got; length -= (size_t)got;
    }
    return 0;
}

/* Выполняет операцию на мосту. Возвращает состояние; данные — в out. */
static int32_t bridge_call(uint8_t op, const void *payload, uint32_t payload_len,
                           void *out, uint32_t out_capacity, uint32_t *out_len)
{
    if (bridge_connect() != 0) return -1;

    unsigned char header[5];
    header[0] = op;
    memcpy(header + 1, &payload_len, 4);

    if (write_all(bridge_fd, header, 5) != 0 ||
        (payload_len && write_all(bridge_fd, payload, payload_len) != 0)) {
        snprintf(last_error, sizeof(last_error), "обрыв связи с мостом при отправке");
        close(bridge_fd); bridge_fd = -1;
        return -1;
    }

    unsigned char response[8];
    if (read_all(bridge_fd, response, 8) != 0) {
        snprintf(last_error, sizeof(last_error), "обрыв связи с мостом при приёме");
        close(bridge_fd); bridge_fd = -1;
        return -1;
    }

    int32_t status; uint32_t length;
    memcpy(&status, response, 4);
    memcpy(&length, response + 4, 4);

    if (out_len) *out_len = 0;
    if (length > 0) {
        unsigned char *buffer = malloc(length);
        if (!buffer) return -1;
        if (read_all(bridge_fd, buffer, length) != 0) {
            free(buffer); close(bridge_fd); bridge_fd = -1;
            return -1;
        }
        if (out && out_capacity > 0) {
            uint32_t copy = length < out_capacity ? length : out_capacity;
            memcpy(out, buffer, copy);
            if (out_len) *out_len = copy;
        }
        free(buffer);
    }
    return status;
}

/* ---- Сборка дерева устройств из дескрипторов ---- */

static void build_device_tree(const unsigned char *blob, uint32_t length)
{
    if (length < 2) return;
    uint16_t device_len = (uint16_t)(blob[0] | (blob[1] << 8));
    if ((uint32_t)device_len + 2 > length) return;

    struct usb_device *device = calloc(1, sizeof(*device));
    struct usb_bus *bus = calloc(1, sizeof(*bus));
    if (!device || !bus) return;

    memcpy(&device->descriptor, blob + 2,
           device_len < sizeof(device->descriptor) ? device_len : sizeof(device->descriptor));

    const unsigned char *config_blob = blob + 2 + device_len;
    uint32_t config_len = length - 2 - device_len;

    if (config_len >= 9) {
        struct usb_config_descriptor *config = calloc(1, sizeof(*config));
        config->bLength = config_blob[0];
        config->bDescriptorType = config_blob[1];
        config->wTotalLength = (uint16_t)(config_blob[2] | (config_blob[3] << 8));
        config->bNumInterfaces = config_blob[4];
        config->bConfigurationValue = config_blob[5];
        config->iConfiguration = config_blob[6];
        config->bmAttributes = config_blob[7];
        config->MaxPower = config_blob[8];

        config->interface = calloc(config->bNumInterfaces ? config->bNumInterfaces : 1,
                                   sizeof(struct usb_interface));

        /* Проходим дескрипторы подряд: интерфейсы и их точки обмена. */
        int interface_index = -1, endpoint_index = 0;
        uint32_t offset = config_blob[0];
        while (offset + 2 <= config_len) {
            uint8_t item_len = config_blob[offset];
            uint8_t item_type = config_blob[offset + 1];
            if (item_len < 2 || offset + item_len > config_len) break;

            if (item_type == 0x04 && item_len >= 9) {          /* интерфейс */
                interface_index++;
                if (interface_index >= config->bNumInterfaces) break;
                struct usb_interface *iface = &config->interface[interface_index];
                iface->altsetting = calloc(1, sizeof(struct usb_interface_descriptor));
                iface->num_altsetting = 1;
                struct usb_interface_descriptor *alt = iface->altsetting;
                alt->bLength = config_blob[offset];
                alt->bDescriptorType = config_blob[offset + 1];
                alt->bInterfaceNumber = config_blob[offset + 2];
                alt->bAlternateSetting = config_blob[offset + 3];
                alt->bNumEndpoints = config_blob[offset + 4];
                alt->bInterfaceClass = config_blob[offset + 5];
                alt->bInterfaceSubClass = config_blob[offset + 6];
                alt->bInterfaceProtocol = config_blob[offset + 7];
                alt->iInterface = config_blob[offset + 8];
                alt->endpoint = calloc(alt->bNumEndpoints ? alt->bNumEndpoints : 1,
                                       sizeof(struct usb_endpoint_descriptor));
                endpoint_index = 0;
                TRACE("интерфейс %d: класс %d, точек обмена %d",
                      alt->bInterfaceNumber, alt->bInterfaceClass, alt->bNumEndpoints);
            } else if (item_type == 0x05 && item_len >= 7 && interface_index >= 0) {  /* точка обмена */
                struct usb_interface_descriptor *alt = config->interface[interface_index].altsetting;
                if (alt && endpoint_index < alt->bNumEndpoints) {
                    struct usb_endpoint_descriptor *ep = &alt->endpoint[endpoint_index++];
                    ep->bLength = config_blob[offset];
                    ep->bDescriptorType = config_blob[offset + 1];
                    ep->bEndpointAddress = config_blob[offset + 2];
                    ep->bmAttributes = config_blob[offset + 3];
                    ep->wMaxPacketSize = (uint16_t)(config_blob[offset + 4] | (config_blob[offset + 5] << 8));
                    ep->bInterval = config_blob[offset + 6];
                    TRACE("  точка обмена 0x%02X, тип %d, пакет %d",
                          ep->bEndpointAddress, ep->bmAttributes & 3, ep->wMaxPacketSize);
                }
            }
            offset += item_len;
        }
        device->config = config;
    }

    snprintf(bus->dirname, sizeof(bus->dirname), "001");
    snprintf(device->filename, sizeof(device->filename), "001");
    device->devnum = 1;
    device->bus = bus;
    bus->devices = device;
    bus->location = 1;
    bus->root_dev = device;

    bus_list = bus;
    the_device = device;
    TRACE("устройство собрано: %04X:%04X", device->descriptor.idVendor, device->descriptor.idProduct);
}

/* ---- Реализация интерфейса libusb-0.1 ---- */

void usb_init(void)
{
    const char *level = getenv("PANASONIC_SHIM_DEBUG");
    if (level) debug_level = atoi(level);
    TRACE("инициализация");
}

void usb_set_debug(int level) { debug_level = level; }

int usb_find_busses(void)
{
    if (bridge_connect() != 0) return 0;
    if (bridge_call(OP_OPEN, NULL, 0, NULL, 0, NULL) < 0) return 0;
    return 1;
}

int usb_find_devices(void)
{
    if (the_device) return 1;

    unsigned char blob[1024];
    uint32_t length = 0;
    int32_t status = bridge_call(OP_DESCRIPTORS, NULL, 0, blob, sizeof(blob), &length);
    if (status < 0 || length == 0) {
        snprintf(last_error, sizeof(last_error), "мост не вернул дескрипторы");
        return 0;
    }
    build_device_tree(blob, length);
    return the_device ? 1 : 0;
}

struct usb_bus *usb_get_busses(void) { return bus_list; }

usb_dev_handle *usb_open(struct usb_device *device)
{
    (void)device;
    if (bridge_call(OP_OPEN, NULL, 0, NULL, 0, NULL) < 0) return NULL;
    /* Настоящий описатель не нужен: устройство у нас единственное. */
    return (usb_dev_handle *)the_device;
}

int usb_close(usb_dev_handle *handle)
{
    (void)handle;
    return bridge_call(OP_CLOSE, NULL, 0, NULL, 0, NULL) < 0 ? -1 : 0;
}

struct usb_device *usb_device(usb_dev_handle *handle) { (void)handle; return the_device; }

int usb_claim_interface(usb_dev_handle *handle, int interface)
{
    (void)handle;
    uint8_t number = (uint8_t)interface;
    return bridge_call(OP_CLAIM, &number, 1, NULL, 0, NULL) < 0 ? -EBUSY : 0;
}

int usb_release_interface(usb_dev_handle *handle, int interface)
{
    (void)handle;
    uint8_t number = (uint8_t)interface;
    return bridge_call(OP_RELEASE, &number, 1, NULL, 0, NULL) < 0 ? -1 : 0;
}

int usb_set_configuration(usb_dev_handle *handle, int configuration)
{
    (void)handle;
    uint8_t value = (uint8_t)configuration;
    return bridge_call(OP_SET_CONFIG, &value, 1, NULL, 0, NULL) < 0 ? -1 : 0;
}

int usb_set_altinterface(usb_dev_handle *handle, int alternate)
{
    (void)handle;
    uint8_t value = (uint8_t)alternate;
    return bridge_call(OP_SET_ALTIFACE, &value, 1, NULL, 0, NULL) < 0 ? -1 : 0;
}

int usb_clear_halt(usb_dev_handle *handle, unsigned int endpoint)
{
    (void)handle;
    uint8_t address = (uint8_t)endpoint;
    return bridge_call(OP_CLEAR_HALT, &address, 1, NULL, 0, NULL) < 0 ? -1 : 0;
}

int usb_control_msg(usb_dev_handle *handle, int requesttype, int request,
                    int value, int index, char *bytes, int size, int timeout)
{
    (void)handle;
    unsigned char payload[13 + 4096];
    if (size < 0 || size > 4096) return -EINVAL;

    payload[0] = (uint8_t)requesttype;
    payload[1] = (uint8_t)request;
    payload[2] = (uint8_t)(value & 0xFF);       payload[3] = (uint8_t)((value >> 8) & 0xFF);
    payload[4] = (uint8_t)(index & 0xFF);       payload[5] = (uint8_t)((index >> 8) & 0xFF);
    payload[6] = (uint8_t)(size & 0xFF);        payload[7] = (uint8_t)((size >> 8) & 0xFF);
    uint32_t t = (uint32_t)timeout;
    memcpy(payload + 8, &t, 4);
    payload[12] = 0;

    uint32_t payload_len = 13;
    int is_input = (requesttype & 0x80) != 0;
    if (!is_input && size > 0 && bytes) {
        memcpy(payload + 13, bytes, (size_t)size);
        payload_len += (uint32_t)size;
    }

    uint32_t received = 0;
    int32_t status = bridge_call(OP_CONTROL, payload, payload_len,
                                 is_input ? bytes : NULL, is_input ? (uint32_t)size : 0, &received);
    if (status < 0) return status;
    return is_input ? (int)received : size;
}

static int transfer(uint8_t op, int endpoint, char *bytes, int size, int timeout, int is_read)
{
    if (size < 0) return -EINVAL;

    if (is_read) {
        unsigned char payload[9];
        payload[0] = (uint8_t)endpoint;
        uint32_t length = (uint32_t)size, t = (uint32_t)timeout;
        memcpy(payload + 1, &length, 4);
        memcpy(payload + 5, &t, 4);
        uint32_t received = 0;
        int32_t status = bridge_call(op, payload, 9, bytes, (uint32_t)size, &received);
        if (status < 0) { snprintf(last_error, sizeof(last_error), "ошибка чтения точки 0x%02X", endpoint); return status; }
        return (int)received;
    }

    unsigned char *payload = malloc(5 + (size_t)size);
    if (!payload) return -ENOMEM;
    payload[0] = (uint8_t)endpoint;
    uint32_t t = (uint32_t)timeout;
    memcpy(payload + 1, &t, 4);
    if (size > 0 && bytes) memcpy(payload + 5, bytes, (size_t)size);
    int32_t status = bridge_call(op, payload, 5 + (uint32_t)size, NULL, 0, NULL);
    free(payload);
    if (status < 0) { snprintf(last_error, sizeof(last_error), "ошибка записи в точку 0x%02X", endpoint); return status; }
    return (int)status;
}

int usb_bulk_read(usb_dev_handle *handle, int ep, char *bytes, int size, int timeout)
{
    (void)handle; return transfer(OP_BULK_READ, ep, bytes, size, timeout, 1);
}

int usb_bulk_write(usb_dev_handle *handle, int ep, char *bytes, int size, int timeout)
{
    (void)handle; return transfer(OP_BULK_WRITE, ep, bytes, size, timeout, 0);
}

int usb_interrupt_read(usb_dev_handle *handle, int ep, char *bytes, int size, int timeout)
{
    (void)handle; return transfer(OP_INTERRUPT_READ, ep, bytes, size, timeout, 1);
}

char *usb_strerror(void) { return last_error; }

/* Вызовы, которых нет в списке нужных бэкенду, но которые может
   запросить libsane: отвечаем безопасно, чтобы не уронить драйвер. */
int usb_reset(usb_dev_handle *handle) { (void)handle; return 0; }

int usb_get_string_simple(usb_dev_handle *handle, int index, char *buffer, size_t size)
{
    (void)handle; (void)index;
    if (buffer && size > 0) buffer[0] = '\0';
    return 0;
}

int usb_get_descriptor(usb_dev_handle *handle, unsigned char type, unsigned char index,
                       void *buffer, int size)
{
    return usb_control_msg(handle, 0x80, 0x06, (type << 8) + index, 0, buffer, size, 1000);
}
