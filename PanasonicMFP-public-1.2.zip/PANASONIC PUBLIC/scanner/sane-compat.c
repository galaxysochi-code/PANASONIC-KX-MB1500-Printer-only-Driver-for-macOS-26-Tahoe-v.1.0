/*
 * Недостающий кусок для связки «scanimage из Debian + libsane от Panasonic».
 *
 * scanimage собран под sane-backends 1.0.31 и требует от libsane.so.1 ровно
 * тринадцать символов. Двенадцать sane_* бэкенд Panasonic (1.0.19)
 * экспортирует, а тринадцатого — md5_buffer — в нём нет: он появился ради
 * аутентификации на saned.
 *
 * scanimage зовёт md5_buffer только из auth_callback, то есть когда бэкенд
 * запросил имя и пароль. Наш бэкенд работает с USB-устройством напрямую и
 * авторизации не запрашивает никогда, поэтому здесь заглушка. Если она вдруг
 * сработает — значит схема поменялась, и об этом будет видно в stderr.
 */

#include <stdio.h>
#include <string.h>
#include <stddef.h>

void *md5_buffer(const char *buffer, size_t len, void *resblock)
{
    (void) buffer;
    (void) len;

    fprintf(stderr,
            "[sane-compat] вызван md5_buffer: бэкенд запросил аутентификацию, "
            "чего в этой схеме быть не должно\n");

    if (resblock)
        memset(resblock, 0, 16);

    return resblock;
}
