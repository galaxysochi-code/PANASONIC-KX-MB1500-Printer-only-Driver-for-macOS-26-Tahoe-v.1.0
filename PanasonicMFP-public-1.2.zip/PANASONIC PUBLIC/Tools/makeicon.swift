#!/usr/bin/env swift
// Генерация AppIcon.icns. Запуск: swift Tools/makeicon.swift
// Рисуем через CGBitmapContext, а не NSImage.lockFocus: в консольном процессе
// фокусировка недоступна и молча возвращает пустое изображение.
import AppKit
import CoreGraphics
import Foundation
import ImageIO
import UniformTypeIdentifiers

// iconutil принимает строго этот набор размеров.
let sizes = [16, 32, 128, 256, 512]
let root = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let iconset = root.appendingPathComponent("build/AppIcon.iconset")
try? FileManager.default.createDirectory(at: iconset, withIntermediateDirectories: true)

/// Глиф принтера из SF Symbols в виде CGImage нужного размера.
func symbolImage(side: CGFloat) -> CGImage? {
    let configuration = NSImage.SymbolConfiguration(pointSize: side, weight: .medium)
    guard let symbol = NSImage(systemSymbolName: "printer.filled.and.paper", accessibilityDescription: nil)?
        .withSymbolConfiguration(configuration) else { return nil }
    var rect = CGRect(origin: .zero, size: symbol.size)
    return symbol.cgImage(forProposedRect: &rect, context: nil, hints: nil)
}

func drawIcon(size: Int) -> Data? {
    let side = CGFloat(size)
    guard let context = CGContext(data: nil, width: size, height: size,
                                  bitsPerComponent: 8, bytesPerRow: 0,
                                  space: CGColorSpaceCreateDeviceRGB(),
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
    else { return nil }

    // Подложка со скруглением и вертикальным градиентом.
    let inset = side * 0.04
    let box = CGRect(x: inset, y: inset, width: side - inset * 2, height: side - inset * 2)
    let path = CGPath(roundedRect: box, cornerWidth: side * 0.22, cornerHeight: side * 0.22, transform: nil)
    context.saveGState()
    context.addPath(path)
    context.clip()
    let colors = [
        CGColor(red: 0.20, green: 0.38, blue: 0.62, alpha: 1),
        CGColor(red: 0.07, green: 0.15, blue: 0.31, alpha: 1)
    ] as CFArray
    if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(),
                                 colors: colors, locations: [0, 1]) {
        context.drawLinearGradient(gradient,
                                   start: CGPoint(x: 0, y: side),
                                   end: CGPoint(x: 0, y: 0),
                                   options: [])
    }
    context.restoreGState()

    // Белый глиф по центру.
    if let glyph = symbolImage(side: side * 0.5) {
        let width = CGFloat(glyph.width)
        let height = CGFloat(glyph.height)
        let scale = min(side * 0.56 / width, side * 0.56 / height)
        let target = CGRect(x: (side - width * scale) / 2,
                            y: (side - height * scale) / 2,
                            width: width * scale,
                            height: height * scale)
        context.saveGState()
        context.clip(to: target, mask: glyph)
        context.setFillColor(CGColor(gray: 1, alpha: 0.95))
        context.fill(target)
        context.restoreGState()
    }

    guard let image = context.makeImage() else { return nil }
    let data = NSMutableData()
    guard let destination = CGImageDestinationCreateWithData(data, UTType.png.identifier as CFString, 1, nil)
    else { return nil }
    CGImageDestinationAddImage(destination, image, nil)
    guard CGImageDestinationFinalize(destination) else { return nil }
    return data as Data
}

var written = 0
for size in sizes {
    for (suffix, pixels) in [("", size), ("@2x", size * 2)] {
        guard let data = drawIcon(size: pixels) else {
            print("не удалось нарисовать \(pixels)px")
            continue
        }
        try data.write(to: iconset.appendingPathComponent("icon_\(size)x\(size)\(suffix).png"))
        written += 1
    }
}
print("PNG создано: \(written)")

let process = Process()
process.executableURL = URL(fileURLWithPath: "/usr/bin/iconutil")
process.arguments = ["-c", "icns", iconset.path,
                     "-o", root.appendingPathComponent("Resources/AppIcon.icns").path]
try process.run()
process.waitUntilExit()
print(process.terminationStatus == 0 ? "AppIcon.icns создан" : "iconutil завершился с ошибкой")
