import SwiftUI

struct ScanView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        HStack(spacing: 0) {
            ScanSettingsPanel(scanner: model.scanner, document: model.document)
                .frame(width: 320)
            Divider()
            VStack(spacing: 0) {
                PageGridView(document: model.document)
                Divider()
                ExportBar(document: model.document)
            }
        }
    }
}

// MARK: - Панель настроек

private struct ScanSettingsPanel: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject var scanner: ScannerController
    @ObservedObject var document: ScanDocument

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                deviceSection
                Divider()
                parametersSection
                Divider()
                actionsSection
            }
            .padding(16)
        }
    }

    private var deviceSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Сканер").font(.headline)
                Spacer()
                Button {
                    Task { await model.refreshEverything() }
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .buttonStyle(.borderless)
                .help("Обновить список устройств")
                .disabled(scanner.isRefreshing)
            }

            if scanner.scanners.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    Label("Сканер не найден", systemImage: "exclamationmark.triangle")
                        .foregroundStyle(.orange)
                    Text("Проверьте раздел «Устройство» — там видно, что именно система обнаружила по USB.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            } else {
                Picker("", selection: $scanner.selectedScannerID) {
                    ForEach(scanner.scanners) { item in
                        Text(item.name).tag(Optional(item.id))
                    }
                }
                .labelsHidden()
                .onChange(of: scanner.selectedScannerID) { _, _ in
                    scanner.updateCapabilities()
                }

                if let selected = scanner.selectedScanner {
                    Text("\(selected.backend.title) · \(selected.detail)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }

    private var parametersSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Параметры").font(.headline)

            Picker("Источник", selection: $scanner.parameters.source) {
                ForEach(scanner.availableSources) { source in
                    Text(source.title).tag(source)
                }
            }

            Picker("Цветность", selection: $scanner.parameters.colorMode) {
                ForEach(ScanColorMode.allCases) { mode in
                    Text(mode.title).tag(mode)
                }
            }

            Picker("Разрешение", selection: $scanner.parameters.dpi) {
                ForEach(scanner.availableResolutions, id: \.self) { dpi in
                    Text("\(dpi) dpi").tag(dpi)
                }
            }

            Picker("Область", selection: $scanner.parameters.paper) {
                ForEach(PaperSize.presets) { paper in
                    Text(paper.name).tag(paper)
                }
            }
        }
    }

    private var actionsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Действия").font(.headline)

            Button {
                Task { await model.scanPage() }
            } label: {
                Label(scanner.parameters.source == .flatbed ? "Сканировать страницу" : "Сканировать пачку",
                      systemImage: "doc.viewfinder")
                    .frame(maxWidth: .infinity)
            }
            .controlSize(.large)
            .buttonStyle(.borderedProminent)
            .disabled(scanner.isScanning || scanner.selectedScanner == nil)

            if scanner.isScanning {
                HStack(spacing: 8) {
                    ProgressView().controlSize(.small)
                    Text(scanner.statusText).font(.caption)
                    Spacer()
                    Button("Отмена") { scanner.cancel() }
                        .buttonStyle(.link)
                }
            }

            Button {
                model.importImages()
            } label: {
                Label("Добавить изображения с диска", systemImage: "photo.on.rectangle")
                    .frame(maxWidth: .infinity)
            }

            Text("Каждое сканирование добавляет страницы в текущий документ. "
                 + "Когда все страницы собраны — сохраните их одним файлом.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
                .padding(.top, 4)
        }
    }
}

// MARK: - Нижняя панель экспорта

private struct ExportBar: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject var document: ScanDocument

    var body: some View {
        VStack(spacing: 10) {
            HStack(spacing: 12) {
                Text("Имя").foregroundStyle(.secondary)
                TextField("Документ", text: $document.title)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 260)

                Picker("Формат", selection: $model.exportSettings.format) {
                    ForEach(ExportFormat.allCases) { format in
                        Text(format.title).tag(format)
                    }
                }
                .frame(maxWidth: 300)

                Spacer()
            }

            HStack(spacing: 8) {
                Text("Куда").foregroundStyle(.secondary)
                Text(model.destinationFolderDisplayPath)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .help(model.destinationFolder.path)
                Button("Изменить…") { model.chooseDestinationFolder() }
                    .buttonStyle(.link)
                Button {
                    NSWorkspace.shared.open(model.destinationFolder)
                } label: {
                    Image(systemName: "folder")
                }
                .buttonStyle(.borderless)
                .help("Открыть папку в Finder")

                Spacer()
            }

            HStack(spacing: 12) {
                if model.exportSettings.format == .pdf || model.exportSettings.format == .pdfSearchable {
                    Toggle("Сжимать изображения", isOn: $model.exportSettings.compressImagesInPDF)
                        .toggleStyle(.checkbox)
                }
                if model.exportSettings.format == .jpeg
                    || ((model.exportSettings.format == .pdf || model.exportSettings.format == .pdfSearchable)
                        && model.exportSettings.compressImagesInPDF) {
                    HStack(spacing: 6) {
                        Text("Качество").foregroundStyle(.secondary)
                        Slider(value: $model.exportSettings.jpegQuality, in: 0.3...1.0)
                            .frame(width: 120)
                        Text(String(format: "%.0f%%", model.exportSettings.jpegQuality * 100))
                            .font(.caption.monospacedDigit())
                            .frame(width: 40, alignment: .leading)
                    }
                }

                Spacer()

                Button {
                    Task { await model.printScannedDocument() }
                } label: {
                    Label("Печать…", systemImage: "printer")
                }
                .disabled(document.isEmpty || model.isExporting)

                Button {
                    Task { await model.exportDocument(askLocation: true) }
                } label: {
                    Label("Сохранить как…", systemImage: "square.and.arrow.down.on.square")
                        .fixedSize()
                }
                .keyboardShortcut("s", modifiers: [.command, .shift])
                .disabled(document.isEmpty || model.isExporting)

                Button {
                    Task { await model.exportDocument() }
                } label: {
                    Label(model.exportSettings.format.isSingleFile
                          ? "Сохранить одним файлом" : "Сохранить страницы",
                          systemImage: "square.and.arrow.down")
                        .fixedSize()
                }
                .keyboardShortcut("s", modifiers: .command)
                .buttonStyle(.borderedProminent)
                .disabled(document.isEmpty || model.isExporting)
            }
        }
        .padding(16)
        .background(.bar)
    }
}
