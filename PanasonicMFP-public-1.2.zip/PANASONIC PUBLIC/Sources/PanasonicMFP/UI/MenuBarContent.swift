import AppKit
import SwiftUI

/// Меню в строке состояния: видно, работает ли служба печати, и можно ею
/// управлять, не открывая окно приложения.
struct MenuBarContent: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        ServiceMenuItems(service: model.service, printer: model.printer)

        Divider()

        Button("Открыть окно…") {
            NSApp.activate(ignoringOtherApps: true)
            for window in NSApp.windows where window.canBecomeMain {
                window.makeKeyAndOrderFront(nil)
            }
        }

        Button("Завершить") {
            NSApp.terminate(nil)
        }
        .keyboardShortcut("q")
    }
}

private struct ServiceMenuItems: View {
    @ObservedObject var service: PrintServiceController
    @ObservedObject var printer: PrintController

    var body: some View {
        Text(service.state.title)

        if case .failed(let message) = service.state, !message.isEmpty {
            Text(String(message.prefix(120)))
        }

        Divider()

        switch service.state {
        case .running:
            Button("Перезапустить службу") {
                Task { await service.restart() }
            }
            Button("Остановить службу") {
                Task { await service.stop() }
            }
        case .starting:
            Text("Подождите…")
        default:
            Button("Запустить службу") {
                Task { await service.start() }
            }
        }

        Divider()

        if printer.printers.isEmpty {
            Text("Очередей печати нет")
        } else {
            ForEach(printer.printers) { queue in
                Text("\(queue.displayName) — \(queue.stateText)")
            }
        }
    }
}
