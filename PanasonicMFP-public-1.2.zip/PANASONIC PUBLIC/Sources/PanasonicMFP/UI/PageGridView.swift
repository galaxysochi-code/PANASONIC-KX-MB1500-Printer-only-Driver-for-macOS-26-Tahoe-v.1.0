import SwiftUI

/// Сетка страниц текущего документа: порядок, поворот, удаление.
struct PageGridView: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject var document: ScanDocument

    private let columns = [GridItem(.adaptive(minimum: 170, maximum: 240), spacing: 16)]

    var body: some View {
        Group {
            if document.isEmpty {
                emptyState
            } else {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 16) {
                        ForEach(Array(document.pages.enumerated()), id: \.element.id) { index, page in
                            PageCell(page: page,
                                     number: index + 1,
                                     isSelected: document.selection.contains(page.id))
                                .onTapGesture {
                                    toggleSelection(page.id)
                                }
                                .contextMenu {
                                    pageMenu(for: page)
                                }
                        }
                    }
                    .padding(16)
                }
                .safeAreaInset(edge: .top) {
                    toolbar
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "doc.text.image")
                .font(.system(size: 46))
                .foregroundStyle(.tertiary)
            Text("Документ пуст")
                .font(.title3)
            Text("Нажмите «Сканировать страницу» слева. Все отсканированные страницы\nсобираются здесь и сохраняются одним файлом.")
                .font(.callout)
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    private var toolbar: some View {
        HStack(spacing: 10) {
            Text(document.summary)
                .font(.callout)
                .foregroundStyle(.secondary)

            Spacer()

            Button {
                rotateTargets(by: -90)
            } label: {
                Image(systemName: "rotate.left")
            }
            .help("Повернуть влево")

            Button {
                rotateTargets(by: 90)
            } label: {
                Image(systemName: "rotate.right")
            }
            .help("Повернуть вправо")

            Button {
                let targets = effectiveTargets()
                document.remove(ids: targets)
            } label: {
                Image(systemName: "trash")
            }
            .help("Удалить выбранные страницы")
            .disabled(document.selection.isEmpty)

            Divider().frame(height: 16)

            Button("Выбрать все") {
                document.selection = Set(document.pages.map(\.id))
            }
            .buttonStyle(.link)

            Button("Очистить документ") {
                document.removeAll()
            }
            .buttonStyle(.link)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 8)
        .background(.bar)
    }

    @ViewBuilder
    private func pageMenu(for page: ScanPage) -> some View {
        Button("Повернуть влево") { document.rotate(ids: [page.id], by: -90) }
        Button("Повернуть вправо") { document.rotate(ids: [page.id], by: 90) }
        Button("Перевернуть") { document.rotate(ids: [page.id], by: 180) }
        Divider()
        Button("Сдвинуть влево") { document.movePage(id: page.id, by: -1) }
        Button("Сдвинуть вправо") { document.movePage(id: page.id, by: 1) }
        Divider()
        Button("Удалить", role: .destructive) { document.remove(ids: [page.id]) }
    }

    private func toggleSelection(_ id: ScanPage.ID) {
        if document.selection.contains(id) {
            document.selection.remove(id)
        } else {
            document.selection.insert(id)
        }
    }

    private func effectiveTargets() -> Set<ScanPage.ID> {
        document.selection.isEmpty ? Set(document.pages.map(\.id)) : document.selection
    }

    private func rotateTargets(by degrees: Int) {
        document.rotate(ids: effectiveTargets(), by: degrees)
    }
}

private struct PageCell: View {
    let page: ScanPage
    let number: Int
    let isSelected: Bool

    var body: some View {
        VStack(spacing: 6) {
            ZStack {
                RoundedRectangle(cornerRadius: 6)
                    .fill(Color(nsColor: .textBackgroundColor))
                    .shadow(radius: 1, y: 1)

                if let thumbnail = page.thumbnail {
                    Image(nsImage: thumbnail)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .rotationEffect(.degrees(0))
                        .padding(6)
                } else {
                    Image(systemName: "doc")
                        .font(.largeTitle)
                        .foregroundStyle(.tertiary)
                }
            }
            .frame(height: 190)
            .overlay(
                RoundedRectangle(cornerRadius: 6)
                    .strokeBorder(isSelected ? Color.accentColor : Color.secondary.opacity(0.25),
                                  lineWidth: isSelected ? 2.5 : 1)
            )

            Text("Стр. \(number)")
                .font(.caption.weight(.medium))
            Text(page.sizeDescription)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
    }
}
