import AppKit
import SwiftUI
import UniformTypeIdentifiers

/// Точка входа. Кроме обычного запуска поддерживает служебный режим
/// `--report` — печать отчёта об оборудовании в терминал.
@main
enum EntryPoint {
    static func main() {
        let arguments = CommandLine.arguments
        if arguments.contains("--report") {
            CLI.printReport()
            exit(0)
        }
        // Проверка USB-тоннеля на живом аппарате: --scan-test [страниц]
        if let index = arguments.firstIndex(of: "--scan-test") {
            let pages = index + 1 < arguments.count ? Int(arguments[index + 1]) ?? 1 : 1
            exit(CLI.testTunnel(pages: pages, dpi: 100) ? 0 : 1)
        }
        PanasonicMFPApp.main()
    }
}

struct PanasonicMFPApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var model = AppModel()

    var body: some Scene {
        WindowGroup("Panasonic MFP", id: Self.mainWindowID) {
            RootView()
                .environmentObject(model)
                .frame(minWidth: 900, minHeight: 600)
        }
        .defaultSize(width: 1100, height: 720)
        .commands {
            CommandGroup(replacing: .newItem) {}
            CommandGroup(after: .appInfo) {
                Button("Обновить список устройств") {
                    Task { await model.refreshEverything() }
                }
                .keyboardShortcut("r", modifiers: .command)
            }
        }

        // Приложение остаётся в строке меню и после закрытия окна: служба печати
        // должна работать, пока пользователь ею пользуется.
        MenuBarExtra {
            MenuBarContent()
                .environmentObject(model)
        } label: {
            Image(systemName: model.service.state.symbol)
        }
    }

    static let mainWindowID = "main"
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    /// Окно можно закрыть — приложение продолжит жить в строке меню.
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { false }

    func applicationDidFinishLaunching(_ notification: Notification) {
        NSApp.setActivationPolicy(.regular)
        NSApp.activate(ignoringOtherApps: true)
    }
}

// MARK: - Модель приложения

@MainActor
final class AppModel: ObservableObject {

    let scanner = ScannerController()
    let document = ScanDocument()
    let printer = PrintController()
    let diagnostics = Diagnostics()
    let service = PrintServiceController()

    @Published var exportSettings = ExportSettings()
    @Published var isExporting = false
    @Published var exportProgress: Double = 0
    @Published var exportStatus = ""
    @Published var infoMessage: String?
    @Published var errorMessage: String?

    /// Папка, куда складываются готовые документы. Запоминается между запусками,
    /// чтобы обычное сохранение обходилось без диалога.
    @Published var destinationFolder: URL = AppModel.storedDestinationFolder {
        didSet {
            UserDefaults.standard.set(destinationFolder.path, forKey: Self.destinationFolderKey)
        }
    }

    private static let destinationFolderKey = "exportDestinationFolder"

    private static var storedDestinationFolder: URL {
        if let path = UserDefaults.standard.string(forKey: destinationFolderKey) {
            let url = URL(fileURLWithPath: path)
            var isDirectory: ObjCBool = false
            if FileManager.default.fileExists(atPath: url.path, isDirectory: &isDirectory),
               isDirectory.boolValue {
                return url
            }
        }
        return FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? FileManager.default.homeDirectoryForCurrentUser
    }

    /// Короткий вид пути для строки настроек: домашний каталог сворачивается в «~».
    var destinationFolderDisplayPath: String {
        (destinationFolder.path as NSString).abbreviatingWithTildeInPath
    }

    init() {
        printer.refresh()
        // Служба печати поднимается в фоне: запуск виртуальной машины занимает
        // десятки секунд и не должен задерживать появление окна.
        Task {
            await service.ensureRunning()
            service.startMonitoring()
            printer.refresh()
        }
    }

    func refreshEverything() async {
        printer.refresh()
        await service.refresh()
        await scanner.refresh()
        await diagnostics.refresh()
    }

    // MARK: - Сканирование

    func scanPage() async {
        let added = await scanner.scanAppending(to: document)
        if let error = scanner.errorMessage {
            errorMessage = error
        } else if added > 0 {
            infoMessage = L("Добавлено страниц") + ": \(added). "
                + L("Всего в документе") + ": \(document.pageCount)."
        }
    }

    // MARK: - Экспорт

    var exportPages: [ExportPage] {
        document.pages.map { ExportPage(fileURL: $0.fileURL, rotation: $0.rotation, dpi: $0.dpi) }
    }

    /// Выбор постоянной папки назначения.
    func chooseDestinationFolder() {
        let panel = NSOpenPanel()
        panel.title = L("Куда сохранять документы")
        panel.prompt = L("Выбрать")
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.directoryURL = destinationFolder
        guard panel.runModal() == .OK, let url = panel.url else { return }
        destinationFolder = url
    }

    /// Имя файла в папке назначения. Существующие файлы не перезаписываются:
    /// к имени добавляется номер.
    private func availableURL(for settings: ExportSettings) -> URL {
        let base = sanitizedTitle()
        let ext = settings.format.fileExtension
        let manager = FileManager.default

        /// Многостраничные форматы дают один файл, остальные — по файлу на страницу
        /// с суффиксом `-001`, поэтому занятость проверяется по обоим вариантам.
        func isTaken(_ name: String) -> Bool {
            if manager.fileExists(atPath: destinationFolder.appendingPathComponent("\(name).\(ext)").path) {
                return true
            }
            guard !settings.format.isSingleFile else { return false }
            return manager.fileExists(
                atPath: destinationFolder.appendingPathComponent("\(name)-001.\(ext)").path)
        }

        var name = base
        var counter = 2
        while isTaken(name) {
            name = "\(base)-\(counter)"
            counter += 1
        }
        return destinationFolder.appendingPathComponent("\(name).\(ext)")
    }

    /// `askLocation` — показать диалог вместо сохранения в выбранную папку.
    func exportDocument(askLocation: Bool = false) async {
        guard !document.isEmpty else {
            errorMessage = L("Сначала отсканируйте хотя бы одну страницу.")
            return
        }

        let settings = currentExportSettings()
        let url: URL

        if askLocation {
            let panel = NSSavePanel()
            panel.title = L("Сохранить документ")
            panel.nameFieldStringValue = "\(sanitizedTitle()).\(settings.format.fileExtension)"
            panel.allowedContentTypes = [settings.format.utType]
            panel.canCreateDirectories = true
            panel.directoryURL = destinationFolder
            if settings.format.isSingleFile == false {
                panel.message = L("Страницы будут сохранены отдельными файлами рядом с указанным именем.")
            }

            guard panel.runModal() == .OK, let chosen = panel.url else { return }
            url = chosen
            // Папку, выбранную в диалоге, запоминаем как новую папку по умолчанию.
            destinationFolder = chosen.deletingLastPathComponent()
        } else {
            guard FileManager.default.isWritableFile(atPath: destinationFolder.path) else {
                errorMessage = L("Папка недоступна для записи") + ": \(destinationFolderDisplayPath)"
                return
            }
            url = availableURL(for: settings)
        }

        isExporting = true
        exportProgress = 0
        exportStatus = L("Подготовка…")
        defer { isExporting = false }

        let pages = exportPages
        let progressHandler: @Sendable (Double, String) -> Void = { [weak self] value, text in
            Task { @MainActor in
                self?.exportProgress = value
                self?.exportStatus = text
            }
        }

        do {
            let created = try await DocumentExporter.export(pages: pages,
                                                            settings: settings,
                                                            to: url,
                                                            progress: progressHandler)
            exportStatus = L("Сохранено")
            let folder = (url.deletingLastPathComponent().path as NSString).abbreviatingWithTildeInPath
            infoMessage = created.count == 1
                ? L("Файл сохранён") + ": \(created[0].lastPathComponent) — \(folder)"
                : L("Сохранено файлов") + ": \(created.count) — \(folder)"
            if let first = created.first {
                NSWorkspace.shared.activateFileViewerSelecting([first])
            }
        } catch {
            errorMessage = error.localizedDescription
            exportStatus = L("Ошибка")
        }
    }

    /// Печать отсканированного документа: собирается временный PDF и отправляется в очередь.
    func printScannedDocument() async {
        guard !document.isEmpty else {
            errorMessage = L("Сначала отсканируйте хотя бы одну страницу.")
            return
        }

        var settings = currentExportSettings()
        settings.format = .pdf
        let temporary = document.workDirectory
            .appendingPathComponent("print-\(Int(Date().timeIntervalSince1970)).pdf")

        isExporting = true
        exportStatus = L("Подготовка к печати…")
        defer { isExporting = false }

        do {
            _ = try await DocumentExporter.export(pages: exportPages, settings: settings, to: temporary)
            printer.printDocument([temporary], title: sanitizedTitle())
            if let error = printer.errorMessage {
                errorMessage = error
            } else {
                infoMessage = L("Документ отправлен на печать.")
            }
            exportStatus = ""
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func currentExportSettings() -> ExportSettings {
        var settings = exportSettings
        settings.documentTitle = sanitizedTitle()
        return settings
    }

    private func sanitizedTitle() -> String {
        let trimmed = document.title.trimmingCharacters(in: .whitespacesAndNewlines)
        let base = trimmed.isEmpty ? L("Документ") : trimmed
        return base.replacingOccurrences(of: "/", with: "-")
    }

    // MARK: - Импорт

    func importImages() {
        let panel = NSOpenPanel()
        panel.title = L("Добавить изображения")
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.allowedContentTypes = [.image, .tiff, .png, .jpeg]
        guard panel.runModal() == .OK else { return }
        let added = document.importFiles(panel.urls, fallbackDPI: scanner.parameters.dpi)
        infoMessage = added > 0
            ? L("Добавлено страниц") + ": \(added)"
            : L("Не удалось прочитать выбранные файлы.")
    }
}
