import SwiftUI

enum SidebarItem: String, CaseIterable, Identifiable {
    case scan
    case printing
    case device

    var id: String { rawValue }

    var title: String {
        switch self {
        case .scan: return L("Сканирование")
        case .printing: return L("Печать")
        case .device: return L("Устройство")
        }
    }

    var symbol: String {
        switch self {
        case .scan: return "scanner"
        case .printing: return "printer"
        case .device: return "cable.connector"
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var model: AppModel
    @State private var selection: SidebarItem = .scan

    var body: some View {
        // Строка состояния вынесена из NavigationSplitView: как safeAreaInset
        // она перекрывала нижние элементы боковой панели и вкладки «Печать».
        VStack(spacing: 0) {
            NavigationSplitView {
                List(SidebarItem.allCases, selection: $selection) { item in
                    Label(item.title, systemImage: item.symbol)
                        .tag(item)
                }
                .navigationSplitViewColumnWidth(min: 180, ideal: 200, max: 240)
            } detail: {
                Group {
                    switch selection {
                    case .scan: ScanView()
                    case .printing: PrintView()
                    case .device: DeviceView()
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }

            StatusBar(service: model.service)
        }
        .task {
            await model.refreshEverything()
        }
    }
}

private struct StatusBar: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject var service: PrintServiceController

    var body: some View {
        VStack(spacing: 0) {
            Divider()
            HStack(spacing: 12) {
                if let error = model.errorMessage {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundStyle(.orange)
                    Text(error)
                        .font(.callout)
                        .textSelection(.enabled)
                        .lineLimit(2)
                    Spacer()
                    Button("Закрыть") { model.errorMessage = nil }
                        .buttonStyle(.link)
                } else if let info = model.infoMessage {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundStyle(.green)
                    Text(info)
                        .font(.callout)
                        .lineLimit(2)
                    Spacer()
                    Button("Закрыть") { model.infoMessage = nil }
                        .buttonStyle(.link)
                } else {
                    Image(systemName: service.state.symbol)
                        .foregroundStyle(service.state.tint)
                    Text(service.state.title)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 16)
            .frame(height: 34)
        }
        .background(.bar)
    }
}
