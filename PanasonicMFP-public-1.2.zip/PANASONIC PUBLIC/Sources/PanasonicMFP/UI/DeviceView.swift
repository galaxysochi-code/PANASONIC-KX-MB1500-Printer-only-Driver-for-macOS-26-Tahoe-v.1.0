import AppKit
import SwiftUI

struct DeviceView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        DevicePanel(diagnostics: model.diagnostics)
    }
}

private struct DevicePanel: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject var diagnostics: Diagnostics

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                header
                statusCard
                usbSection
                cupsSection
                queueSection
                scannerSection
                driverSection
            }
            .padding(20)
            .frame(maxWidth: 900, alignment: .leading)
        }
        .frame(maxWidth: .infinity)
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Состояние оборудования")
                    .font(.title2.weight(.semibold))
                if let last = diagnostics.lastRefresh {
                    Text("Обновлено: \(last.formatted(date: .omitted, time: .standard))")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            Button {
                let report = diagnostics.makeReport()
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(report, forType: .string)
                model.infoMessage = "Отчёт скопирован в буфер обмена."
            } label: {
                Label("Скопировать отчёт", systemImage: "doc.on.clipboard")
            }
            Button {
                Task { await model.refreshEverything() }
            } label: {
                Label("Обновить", systemImage: "arrow.clockwise")
            }
            .buttonStyle(.borderedProminent)
            .disabled(diagnostics.isRefreshing)
        }
    }

    private var statusCard: some View {
        let connected = diagnostics.isMFPConnected
        return HStack(spacing: 14) {
            Image(systemName: connected ? "checkmark.circle.fill" : "questionmark.circle.fill")
                .font(.system(size: 34))
                .foregroundStyle(connected ? .green : .orange)
            VStack(alignment: .leading, spacing: 3) {
                Text(connected ? "МФУ Panasonic подключено по USB" : "МФУ Panasonic не обнаружено")
                    .font(.headline)
                if connected {
                    ForEach(diagnostics.panasonicUSB) { device in
                        Text("\(device.displayName) · \(device.vidPid)")
                            .font(.callout)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                } else {
                    Text("Включите аппарат и подключите его кабелем USB к этому компьютеру, затем нажмите «Обновить».")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
            Spacer()
        }
        .padding(16)
        .background(.quaternary.opacity(0.4), in: RoundedRectangle(cornerRadius: 10))
    }

    private var usbSection: some View {
        DiagnosticSection(title: "USB-устройства", count: diagnostics.usbDevices.count) {
            if diagnostics.usbDevices.isEmpty {
                emptyRow("Устройств не найдено")
            }
            ForEach(diagnostics.usbDevices) { device in
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 6) {
                        if device.isPanasonic {
                            Image(systemName: "star.fill").foregroundStyle(.yellow).font(.caption)
                        }
                        Text(device.displayName).fontWeight(.medium)
                        Text(device.vidPid)
                            .font(.caption.monospaced())
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                    if !device.serial.isEmpty {
                        Text("серийный номер: \(device.serial)")
                            .font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                    }
                    ForEach(device.interfaces, id: \.self) { interface in
                        Text(interface.summary).font(.caption).foregroundStyle(.secondary)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }

    private var cupsSection: some View {
        DiagnosticSection(title: "Что видит подсистема печати (CUPS)", count: diagnostics.cupsDevices.count) {
            if diagnostics.cupsDevices.isEmpty {
                emptyRow("CUPS не обнаружила подключённых устройств")
            }
            ForEach(diagnostics.cupsDevices) { device in
                VStack(alignment: .leading, spacing: 3) {
                    Text(device.uri).font(.callout.monospaced()).textSelection(.enabled)
                    if !device.makeAndModel.isEmpty {
                        Text(device.makeAndModel).font(.caption)
                    }
                    if !device.deviceID.isEmpty {
                        Text(device.deviceID)
                            .font(.caption2.monospaced())
                            .foregroundStyle(.tertiary)
                            .textSelection(.enabled)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }

    private var queueSection: some View {
        DiagnosticSection(title: "Очереди печати", count: diagnostics.printers.count) {
            if diagnostics.printers.isEmpty { emptyRow("Очередей нет") }
            ForEach(diagnostics.printers) { printer in
                VStack(alignment: .leading, spacing: 2) {
                    HStack {
                        Text(printer.name).fontWeight(.medium)
                        if printer.isDefault {
                            Text("по умолчанию")
                                .font(.caption2)
                                .padding(.horizontal, 6).padding(.vertical, 1)
                                .background(.tint.opacity(0.15), in: Capsule())
                        }
                        Spacer()
                        Text(printer.stateText).font(.caption).foregroundStyle(.secondary)
                    }
                    Text(printer.deviceURI).font(.caption.monospaced()).foregroundStyle(.secondary)
                }
                .padding(.vertical, 4)
            }
        }
    }

    private var scannerSection: some View {
        DiagnosticSection(title: "Сканеры", count: diagnostics.scanners.count) {
            if diagnostics.scanners.isEmpty {
                emptyRow("Система не видит ни одного сканера")
            }
            ForEach(diagnostics.scanners) { scanner in
                HStack {
                    Text(scanner.name)
                    Spacer()
                    Text(scanner.detail).font(.caption).foregroundStyle(.secondary)
                }
                .padding(.vertical, 3)
            }
        }
    }

    private var driverSection: some View {
        DiagnosticSection(title: "Драйверы", count: diagnostics.driverStatus.count) {
            ForEach(diagnostics.driverStatus) { status in
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: status.usable ? "checkmark.circle.fill" : "xmark.octagon.fill")
                        .foregroundStyle(status.usable ? .green : .red)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(status.component).fontWeight(.medium)
                        Text(status.detail).font(.caption).foregroundStyle(.secondary)
                            .fixedSize(horizontal: false, vertical: true)
                        Text(status.path).font(.caption2.monospaced()).foregroundStyle(.tertiary)
                            .textSelection(.enabled)
                    }
                }
                .padding(.vertical, 4)
            }
        }
    }

    private func emptyRow(_ text: String) -> some View {
        Text(text).font(.callout).foregroundStyle(.secondary).padding(.vertical, 4)
    }
}

private struct DiagnosticSection<Content: View>: View {
    let title: String
    let count: Int
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title).font(.headline)
                Text("\(count)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .padding(.horizontal, 6).padding(.vertical, 1)
                    .background(.quaternary, in: Capsule())
            }
            VStack(alignment: .leading, spacing: 0) {
                content
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(.quaternary.opacity(0.3), in: RoundedRectangle(cornerRadius: 8))
        }
    }
}
