import AppKit
import SwiftUI
import UniformTypeIdentifiers

struct PrintView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        PrintPanel(printer: model.printer)
    }
}

/// Состояние службы преобразования. Без неё системная очередь не напечатает
/// ничего: задание уйдёт в CUPS и завершится ошибкой бэкенда.
private struct ServiceStatusCard: View {
    @ObservedObject var service: PrintServiceController

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Драйвер Panasonic").font(.headline)

            HStack(spacing: 8) {
                if service.state.isBusy {
                    ProgressView().controlSize(.small)
                } else {
                    Image(systemName: service.state.symbol)
                        .foregroundStyle(service.state.tint)
                }
                Text(service.state.title)
                    .font(.callout)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
            }

            if !service.detail.isEmpty, service.state != .running {
                Text(service.detail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(4)
                    .fixedSize(horizontal: false, vertical: true)
                    .textSelection(.enabled)
            }

            HStack(spacing: 8) {
                if service.state == .running {
                    Button("Перезапустить") { Task { await service.restart() } }
                } else {
                    Button("Запустить") { Task { await service.start() } }
                        .buttonStyle(.borderedProminent)
                }
                Button("Обновить") { Task { await service.refresh() } }
            }
            .disabled(service.state.isBusy)
            .controlSize(.small)
        }
    }
}

private struct PrintPanel: View {
    @EnvironmentObject private var model: AppModel
    @ObservedObject var printer: PrintController
    @State private var selectedFiles: Set<URL> = []

    var body: some View {
        HStack(spacing: 0) {
            settingsColumn
                .frame(width: 320)
            Divider()
            filesColumn
        }
    }

    // MARK: - Настройки

    private var settingsColumn: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                ServiceStatusCard(service: model.service)
                Divider()
                printerSection
                Divider()
                optionsSection
                Divider()
                jobsSection
            }
            .padding(16)
        }
    }

    private var printerSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("Принтер").font(.headline)
                Spacer()
                Button {
                    printer.refresh()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .buttonStyle(.borderless)
                .help("Обновить список очередей")
            }

            if printer.printers.isEmpty {
                VStack(alignment: .leading, spacing: 6) {
                    Label("Очередей печати нет", systemImage: "exclamationmark.triangle")
                        .foregroundStyle(.orange)
                    Text("Проверьте раздел «Устройство» — там видно, что именно система обнаружила по USB.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            } else {
                Picker("", selection: $printer.selectedPrinterName) {
                    ForEach(printer.printers) { item in
                        Text(item.displayName).tag(Optional(item.name))
                    }
                }
                .labelsHidden()

                if let selected = printer.selectedPrinter {
                    VStack(alignment: .leading, spacing: 2) {
                        Text(selected.makeAndModel.isEmpty ? selected.name : selected.makeAndModel)
                            .font(.caption)
                        Text(selected.deviceURI)
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                            .textSelection(.enabled)
                    }
                }
            }
        }
    }

    private var optionsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Параметры").font(.headline)

            Stepper(value: $printer.copies, in: 1...99) {
                Text("Копий: \(printer.copies)")
            }

            Picker("Формат", selection: $printer.media) {
                ForEach(PrintController.mediaPresets, id: \.self) { Text($0).tag($0) }
            }

            Picker("Качество", selection: $printer.quality) {
                ForEach(PrintController.qualityPresets, id: \.0) { value, title in
                    Text(L(title)).tag(value)
                }
            }

            HStack {
                Text("Страницы")
                TextField("напр. 1-3,5", text: $printer.pageRanges)
                    .textFieldStyle(.roundedBorder)
            }

            Toggle("Вписать в страницу", isOn: $printer.fitToPage)
            Toggle("Альбомная ориентация", isOn: $printer.landscape)
        }
    }

    private var jobsSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Очередь заданий").font(.headline)
            if printer.jobs.isEmpty {
                Text("Активных заданий нет")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            } else {
                ForEach(printer.jobs) { job in
                    HStack {
                        VStack(alignment: .leading, spacing: 1) {
                            Text(job.id).font(.caption.monospaced())
                            Text("\(job.user) · \(job.size)")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Button("Отменить") { printer.cancelJob(job) }
                            .buttonStyle(.link)
                    }
                }
            }
        }
    }

    // MARK: - Файлы

    private var filesColumn: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Button {
                    openFiles()
                } label: {
                    Label("Добавить файлы", systemImage: "plus")
                }

                Button {
                    printer.removeFiles(selectedFiles)
                    selectedFiles.removeAll()
                } label: {
                    Label("Убрать", systemImage: "minus")
                }
                .disabled(selectedFiles.isEmpty)

                Spacer()
            }
            .padding(12)

            Divider()

            if printer.files.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "tray.and.arrow.down")
                        .font(.system(size: 42))
                        .foregroundStyle(.tertiary)
                    Text("Перетащите сюда PDF или изображения")
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List(selection: $selectedFiles) {
                    ForEach(printer.files, id: \.self) { url in
                        HStack {
                            Image(nsImage: NSWorkspace.shared.icon(forFile: url.path))
                                .resizable()
                                .frame(width: 20, height: 20)
                            VStack(alignment: .leading, spacing: 1) {
                                Text(url.lastPathComponent)
                                Text(url.deletingLastPathComponent().path)
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .lineLimit(1)
                                    .truncationMode(.head)
                            }
                            Spacer()
                            if !DocumentConverter.isKnown(url) {
                                Label("формат не поддерживается", systemImage: "exclamationmark.triangle.fill")
                                    .labelStyle(.iconOnly)
                                    .foregroundStyle(.orange)
                                    .help("Этот формат нельзя напечатать. Сохраните файл в PDF.")
                            } else if DocumentConverter.needsConversion(url) {
                                Text("→ PDF")
                                    .font(.caption2)
                                    .foregroundStyle(.secondary)
                                    .help("Будет автоматически преобразован в PDF перед печатью")
                            }
                        }
                        .tag(url)
                    }
                }
            }

            Divider()

            HStack {
                Text(printer.statusText)
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                Spacer()
                Button {
                    printer.printWithSystemPanel(urls: printer.files)
                } label: {
                    Label("Системный диалог…", systemImage: "slider.horizontal.3")
                }
                .disabled(printer.files.isEmpty)

                Button {
                    printer.printSelectedFiles()
                    if let error = printer.errorMessage {
                        model.errorMessage = error
                        printer.errorMessage = nil
                    } else {
                        model.infoMessage = "Задание отправлено в очередь."
                    }
                } label: {
                    Label("Печать", systemImage: "printer.fill")
                }
                .buttonStyle(.borderedProminent)
                .disabled(printer.files.isEmpty || printer.selectedPrinterName == nil)
            }
            .padding(12)
            .background(.bar)
        }
        .onDrop(of: [.fileURL], isTargeted: nil) { providers in
            handleDrop(providers)
        }
    }

    private func openFiles() {
        let panel = NSOpenPanel()
        panel.title = "Файлы для печати"
        panel.message = "PDF и изображения печатаются напрямую; Word, RTF, ODT и HTML "
                      + "автоматически преобразуются в PDF."
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        // Тип файла не ограничиваем: неподдерживаемый формат честно сообщит об этом при печати.
        guard panel.runModal() == .OK else { return }
        printer.addFiles(panel.urls)
    }

    private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
        var handled = false
        for provider in providers where provider.hasItemConformingToTypeIdentifier(UTType.fileURL.identifier) {
            handled = true
            _ = provider.loadObject(ofClass: URL.self) { url, _ in
                guard let url else { return }
                Task { @MainActor in
                    printer.addFiles([url])
                }
            }
        }
        return handled
    }
}
