import CoreGraphics
import CoreText
import Foundation
import ImageIO
import UniformTypeIdentifiers
import Vision

enum ExportFormat: String, CaseIterable, Identifiable, Codable {
    case pdf
    case pdfSearchable
    case tiff
    case jpeg
    case png

    var id: String { rawValue }

    var title: String {
        switch self {
        case .pdf: return L("PDF (один файл)")
        case .pdfSearchable: return L("PDF с текстовым слоем (OCR)")
        case .tiff: return L("Многостраничный TIFF")
        case .jpeg: return L("JPEG (по файлу на страницу)")
        case .png: return L("PNG (по файлу на страницу)")
        }
    }

    var isSingleFile: Bool {
        switch self {
        case .pdf, .pdfSearchable, .tiff: return true
        case .jpeg, .png: return false
        }
    }

    var fileExtension: String {
        switch self {
        case .pdf, .pdfSearchable: return "pdf"
        case .tiff: return "tiff"
        case .jpeg: return "jpg"
        case .png: return "png"
        }
    }

    var utType: UTType {
        switch self {
        case .pdf, .pdfSearchable: return .pdf
        case .tiff: return .tiff
        case .jpeg: return .jpeg
        case .png: return .png
        }
    }
}

struct ExportSettings {
    var format: ExportFormat = .pdf
    var jpegQuality: Double = 0.8
    /// Пережимать страницы в JPEG внутри PDF (заметно уменьшает размер для серых/цветных сканов).
    var compressImagesInPDF: Bool = true
    var ocrLanguages: [String] = ["ru-RU", "en-US"]
    var documentTitle: String = "Документ"
}

/// Страница в форме, пригодной для фоновой обработки.
struct ExportPage: Sendable {
    let fileURL: URL
    let rotation: Int
    let dpi: Int
}

enum ExportError: LocalizedError {
    case noPages
    case cannotCreateFile(String)
    case renderFailed(String)

    var errorDescription: String? {
        switch self {
        case .noPages: return L("Нет страниц для сохранения.")
        case .cannotCreateFile(let path): return "Не удалось создать файл: \(path)"
        case .renderFailed(let message): return "Ошибка при формировании документа: \(message)"
        }
    }
}

enum DocumentExporter {

    /// Основная точка входа. Возвращает список созданных файлов.
    static func export(pages: [ExportPage],
                       settings: ExportSettings,
                       to destination: URL,
                       progress: (@Sendable (Double, String) -> Void)? = nil) async throws -> [URL] {
        guard !pages.isEmpty else { throw ExportError.noPages }

        return try await withCheckedThrowingContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                do {
                    let urls: [URL]
                    switch settings.format {
                    case .pdf:
                        try writePDF(pages: pages, settings: settings, ocr: false,
                                     to: destination, progress: progress)
                        urls = [destination]
                    case .pdfSearchable:
                        try writePDF(pages: pages, settings: settings, ocr: true,
                                     to: destination, progress: progress)
                        urls = [destination]
                    case .tiff:
                        try writeMultipageTIFF(pages: pages, to: destination, progress: progress)
                        urls = [destination]
                    case .jpeg, .png:
                        urls = try writeSeparateImages(pages: pages, settings: settings,
                                                       to: destination, progress: progress)
                    }
                    continuation.resume(returning: urls)
                } catch {
                    continuation.resume(throwing: error)
                }
            }
        }
    }

    // MARK: - PDF

    static func writePDF(pages: [ExportPage],
                         settings: ExportSettings,
                         ocr: Bool,
                         to destination: URL,
                         progress: (@Sendable (Double, String) -> Void)? = nil) throws {
        guard let consumer = CGDataConsumer(url: destination as CFURL) else {
            throw ExportError.cannotCreateFile(destination.path)
        }

        let info: [String: Any] = [
            kCGPDFContextTitle as String: settings.documentTitle,
            kCGPDFContextCreator as String: "Panasonic MFP",
            kCGPDFContextAuthor as String: NSUserName()
        ]

        var initialBox = CGRect(x: 0, y: 0, width: 595, height: 842)
        guard let context = CGContext(consumer: consumer, mediaBox: &initialBox, info as CFDictionary) else {
            throw ExportError.cannotCreateFile(destination.path)
        }

        let total = Double(pages.count)
        for (index, page) in pages.enumerated() {
            progress?(Double(index) / total, "Страница \(index + 1) из \(pages.count)")

            guard let image = loadImage(page) else {
                throw ExportError.renderFailed(page.fileURL.lastPathComponent)
            }

            let widthPoints = CGFloat(image.width) * 72.0 / CGFloat(max(page.dpi, 1))
            let heightPoints = CGFloat(image.height) * 72.0 / CGFloat(max(page.dpi, 1))
            let box = CGRect(x: 0, y: 0, width: widthPoints, height: heightPoints)

            let boxData = withUnsafeBytes(of: box) { Data($0) } as CFData
            let pageInfo: [String: Any] = [kCGPDFContextMediaBox as String: boxData]

            context.beginPDFPage(pageInfo as CFDictionary)
            let drawable = settings.compressImagesInPDF
                ? (recompressedJPEG(image, quality: settings.jpegQuality) ?? image)
                : image
            context.draw(drawable, in: box)

            if ocr {
                progress?((Double(index) + 0.5) / total, "Распознавание текста, страница \(index + 1)")
                let observations = recognizeText(in: image, languages: settings.ocrLanguages)
                drawInvisibleText(observations, in: context, pageBox: box)
            }

            context.endPDFPage()
        }

        context.closePDF()
        progress?(1.0, "Готово")
    }

    // MARK: - TIFF

    static func writeMultipageTIFF(pages: [ExportPage],
                                   to destination: URL,
                                   progress: (@Sendable (Double, String) -> Void)? = nil) throws {
        guard let dest = CGImageDestinationCreateWithURL(destination as CFURL,
                                                         UTType.tiff.identifier as CFString,
                                                         pages.count, nil) else {
            throw ExportError.cannotCreateFile(destination.path)
        }

        let total = Double(pages.count)
        for (index, page) in pages.enumerated() {
            progress?(Double(index) / total, "Страница \(index + 1) из \(pages.count)")
            guard let image = loadImage(page) else {
                throw ExportError.renderFailed(page.fileURL.lastPathComponent)
            }
            let properties: [CFString: Any] = [
                kCGImagePropertyDPIWidth: page.dpi,
                kCGImagePropertyDPIHeight: page.dpi,
                kCGImagePropertyTIFFDictionary: [
                    kCGImagePropertyTIFFCompression: 5,      // LZW
                    kCGImagePropertyTIFFXResolution: page.dpi,
                    kCGImagePropertyTIFFYResolution: page.dpi,
                    kCGImagePropertyTIFFResolutionUnit: 2
                ] as [CFString: Any]
            ]
            CGImageDestinationAddImage(dest, image, properties as CFDictionary)
        }

        guard CGImageDestinationFinalize(dest) else {
            throw ExportError.renderFailed(destination.lastPathComponent)
        }
        progress?(1.0, "Готово")
    }

    // MARK: - Отдельные изображения

    static func writeSeparateImages(pages: [ExportPage],
                                    settings: ExportSettings,
                                    to destination: URL,
                                    progress: (@Sendable (Double, String) -> Void)? = nil) throws -> [URL] {
        let directory = destination.deletingLastPathComponent()
        let base = destination.deletingPathExtension().lastPathComponent
        let ext = settings.format.fileExtension
        var created: [URL] = []
        let total = Double(pages.count)

        for (index, page) in pages.enumerated() {
            progress?(Double(index) / total, "Страница \(index + 1) из \(pages.count)")
            guard let image = loadImage(page) else {
                throw ExportError.renderFailed(page.fileURL.lastPathComponent)
            }
            let name = pages.count == 1 ? "\(base).\(ext)"
                                        : String(format: "%@-%03d.%@", base, index + 1, ext)
            let url = directory.appendingPathComponent(name)
            guard let dest = CGImageDestinationCreateWithURL(url as CFURL,
                                                             settings.format.utType.identifier as CFString,
                                                             1, nil) else {
                throw ExportError.cannotCreateFile(url.path)
            }
            var properties: [CFString: Any] = [
                kCGImagePropertyDPIWidth: page.dpi,
                kCGImagePropertyDPIHeight: page.dpi
            ]
            if settings.format == .jpeg {
                properties[kCGImageDestinationLossyCompressionQuality] = settings.jpegQuality
            }
            CGImageDestinationAddImage(dest, image, properties as CFDictionary)
            guard CGImageDestinationFinalize(dest) else {
                throw ExportError.renderFailed(url.lastPathComponent)
            }
            created.append(url)
        }
        progress?(1.0, "Готово")
        return created
    }

    // MARK: - Вспомогательное

    private static func loadImage(_ page: ExportPage) -> CGImage? {
        guard let source = CGImageSourceCreateWithURL(page.fileURL as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, nil) else { return nil }
        return ScanPage.rotate(image, by: page.rotation)
    }

    /// Пережатие в JPEG для уменьшения размера PDF. Для 1-битных изображений не применяется.
    private static func recompressedJPEG(_ image: CGImage, quality: Double) -> CGImage? {
        guard image.bitsPerComponent > 1 else { return nil }
        let data = NSMutableData()
        guard let dest = CGImageDestinationCreateWithData(data, UTType.jpeg.identifier as CFString, 1, nil) else {
            return nil
        }
        CGImageDestinationAddImage(dest, image,
                                   [kCGImageDestinationLossyCompressionQuality: quality] as CFDictionary)
        guard CGImageDestinationFinalize(dest),
              let source = CGImageSourceCreateWithData(data as CFData, nil) else { return nil }
        return CGImageSourceCreateImageAtIndex(source, 0, nil)
    }

    struct TextBox {
        let text: String
        /// Нормализованный прямоугольник (origin — левый нижний угол).
        let rect: CGRect
    }

    static func recognizeText(in image: CGImage, languages: [String]) -> [TextBox] {
        let request = VNRecognizeTextRequest()
        request.recognitionLevel = .accurate
        request.usesLanguageCorrection = true
        if !languages.isEmpty { request.recognitionLanguages = languages }

        let handler = VNImageRequestHandler(cgImage: image, options: [:])
        do {
            try handler.perform([request])
        } catch {
            return []
        }

        guard let results = request.results else { return [] }
        return results.compactMap { observation in
            guard let candidate = observation.topCandidates(1).first else { return nil }
            let text = candidate.string.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !text.isEmpty else { return nil }
            return TextBox(text: text, rect: observation.boundingBox)
        }
    }

    /// Невидимый текстовый слой поверх картинки — PDF становится доступным для поиска и копирования.
    static func drawInvisibleText(_ boxes: [TextBox], in context: CGContext, pageBox: CGRect) {
        guard !boxes.isEmpty else { return }
        context.saveGState()
        context.setTextDrawingMode(.invisible)

        for box in boxes {
            let rect = CGRect(x: box.rect.minX * pageBox.width,
                              y: box.rect.minY * pageBox.height,
                              width: box.rect.width * pageBox.width,
                              height: box.rect.height * pageBox.height)
            guard rect.width > 0.5, rect.height > 0.5 else { continue }

            let fontSize = max(rect.height * 0.8, 1)
            let font = CTFontCreateWithName("Helvetica" as CFString, fontSize, nil)
            let attributed = NSAttributedString(string: box.text, attributes: [.font: font])
            let line = CTLineCreateWithAttributedString(attributed)
            let typographicWidth = CTLineGetTypographicBounds(line, nil, nil, nil)
            let scaleX = typographicWidth > 0 ? rect.width / CGFloat(typographicWidth) : 1

            context.textMatrix = CGAffineTransform(scaleX: scaleX, y: 1)
            context.textPosition = CGPoint(x: rect.minX, y: rect.minY + rect.height * 0.15)
            CTLineDraw(line, context)
        }

        context.restoreGState()
    }
}
