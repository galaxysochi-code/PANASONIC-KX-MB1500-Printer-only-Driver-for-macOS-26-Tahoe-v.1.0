import Foundation

/// Каким путём получено изображение.
enum ScannerBackendKind: String, Codable {
    /// Штатный путь macOS. Для KX-MB1500 неработоспособен: модуль Panasonic
    /// ссылается на удалённые из системы символы Carbon (см. README). Остаётся
    /// ради раздела диагностики — показать, что именно видит система.
    case imageCapture
    /// USB-тоннель: родной SANE-бэкенд Panasonic работает в контейнере,
    /// его обращения к libusb уходят мосту на стороне macOS.
    case tunnel

    var title: String {
        switch self {
        case .imageCapture: return "ImageCapture"
        case .tunnel: return L("USB-мост")
        }
    }
}

/// Сведения о сканере: и для раздела диагностики, и для выбора устройства.
struct ScannerRef: Identifiable, Hashable {
    let id: String
    let name: String
    let detail: String
    var backend: ScannerBackendKind = .imageCapture
}
