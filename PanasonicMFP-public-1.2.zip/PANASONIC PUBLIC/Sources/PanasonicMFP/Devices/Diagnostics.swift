import Foundation

/// Сбор всей информации, необходимой для подключения KX-MB1500:
/// что видит USB-стек, что видит CUPS, что видит ImageCapture и в каком
/// состоянии находятся штатные драйверы Panasonic.
@MainActor
final class Diagnostics: ObservableObject {

    struct DriverStatus: Identifiable {
        let id = UUID()
        let component: String
        let path: String
        let detail: String
        let usable: Bool
    }

    @Published private(set) var usbDevices: [USBDevice] = []
    @Published private(set) var cupsDevices: [CUPSDiscoveredDevice] = []
    @Published private(set) var printers: [CUPSPrinter] = []
    @Published private(set) var scanners: [ScannerRef] = []
    @Published private(set) var driverStatus: [DriverStatus] = []
    @Published private(set) var isRefreshing = false
    @Published private(set) var lastRefresh: Date?

    func refresh() async {
        isRefreshing = true
        defer { isRefreshing = false; lastRefresh = Date() }

        let usb = await Task.detached { USBDiscovery.scan() }.value
        let cups = await Task.detached { CUPS.discoveredDevices() }.value
        let queues = await Task.detached { CUPS.printers() }.value
        let drivers = await Task.detached { Diagnostics.collectDriverStatus() }.value

        usbDevices = usb
        cupsDevices = cups
        printers = queues
        driverStatus = drivers
        scanners = CLI.browseScanners(timeout: 1.5)
    }

    var panasonicUSB: [USBDevice] { usbDevices.filter(\.isPanasonic) }
    var isMFPConnected: Bool { !panasonicUSB.isEmpty }

    // MARK: - Состояние штатных драйверов

    nonisolated static let printFilterPath = "/Library/Printers/Panasonic/Filter/M_H0JDGCZMZ"
    nonisolated static let icaModulePath = "/Library/Image Capture/Devices/Panasonic MFS Scanner.app"
    /// USB product ID аппарата KX-MB1500RU.
    nonisolated static let kxMB1500ProductID = "0x0F0B"

    nonisolated static func collectDriverStatus() -> [DriverStatus] {
        var result: [DriverStatus] = []
        let fileManager = FileManager.default

        // Фильтр печати Panasonic для macOS.
        if fileManager.fileExists(atPath: printFilterPath) {
            let architectures = architectures(of: printFilterPath)
            let usable = architectures.contains("arm64") || architectures.contains("x86_64")
            result.append(DriverStatus(
                component: "Фильтр печати Panasonic (macOS)",
                path: printFilterPath,
                detail: architectures.isEmpty
                    ? "не удалось определить архитектуру"
                    : "архитектуры: \(architectures.joined(separator: ", "))"
                        + (usable ? "" : " — 32-битный код, на macOS 11+ не запускается"),
                usable: usable))
        } else {
            result.append(DriverStatus(component: "Фильтр печати Panasonic (macOS)", path: printFilterPath,
                                       detail: "не установлен (и не требуется — печать идёт через контейнер)",
                                       usable: false))
        }

        // ICA-модуль сканера.
        let icaBinary = icaModulePath + "/Contents/MacOS/Panasonic MFS Scanner"
        if fileManager.fileExists(atPath: icaBinary) {
            let architectures = architectures(of: icaBinary)
            let knowsDevice = supportedProductIDs(plist: icaModulePath + "/Contents/Info.plist")
                .contains(kxMB1500ProductID)
            let legacySymbols = missingCarbonSymbols(binary: icaBinary)

            var detail = "архитектуры: \(architectures.joined(separator: ", "))"
            detail += knowsDevice ? "; KX-MB1500 (PID 0x0F0B) в списке есть" : "; KX-MB1500 в списке отсутствует"
            if !legacySymbols.isEmpty {
                detail += "; модуль не загружается — ссылается на удалённый Carbon-API "
                        + "(\(legacySymbols.count) символов, напр. \(legacySymbols[0]))"
            }
            result.append(DriverStatus(component: "ICA-модуль сканера Panasonic", path: icaModulePath,
                                       detail: detail,
                                       usable: knowsDevice && legacySymbols.isEmpty))
        } else {
            result.append(DriverStatus(component: "ICA-модуль сканера Panasonic", path: icaModulePath,
                                       detail: "не установлен", usable: false))
        }

        // Собственный бэкенд печати.
        let backend = "/usr/libexec/cups/backend/panasonic"
        result.append(DriverStatus(
            component: "Бэкенд печати этого проекта",
            path: backend,
            detail: fileManager.isExecutableFile(atPath: backend) ? "установлен" : "не установлен",
            usable: fileManager.isExecutableFile(atPath: backend)))

        // Средства запуска контейнера.
        if let colima = Shell.which("colima") {
            result.append(DriverStatus(component: "colima (виртуальная машина Linux)", path: colima,
                                       detail: "установлена", usable: true))
        } else {
            result.append(DriverStatus(component: "colima (виртуальная машина Linux)", path: "—",
                                       detail: "не установлена — выполните: brew install colima docker",
                                       usable: false))
        }

        return result
    }

    nonisolated static func architectures(of path: String) -> [String] {
        guard let lipo = Shell.which("lipo") else { return [] }
        let result = Shell.run(lipo, ["-archs", path])
        guard result.ok else { return [] }
        return result.out.split(separator: " ")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
    }

    nonisolated static func supportedProductIDs(plist: String) -> [String] {
        guard let plutil = Shell.which("plutil") else { return [] }
        let result = Shell.run(plutil, ["-p", plist])
        guard result.ok else { return [] }
        return result.out.split(separator: "\n")
            .filter { $0.contains("idProduct") }
            .compactMap { line in
                guard let range = line.range(of: "=> ") else { return nil }
                return String(line[range.upperBound...])
                    .trimmingCharacters(in: CharacterSet(charactersIn: "\" "))
                    .uppercased()
                    .replacingOccurrences(of: "0X", with: "0x")
            }
    }

    /// Символы Carbon Image Capture, удалённые Apple из современной macOS.
    /// Если модуль на них ссылается, dyld не сможет его загрузить.
    nonisolated static func missingCarbonSymbols(binary: String) -> [String] {
        guard let nm = Shell.which("nm") else { return [] }
        let result = Shell.run(nm, ["-arch", "x86_64", "-u", binary])
        guard result.ok else { return [] }
        return result.out.split(separator: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { $0.hasPrefix("_kICA") || $0.hasPrefix("_ICA") }
    }

    // MARK: - Текстовый отчёт

    func makeReport() -> String {
        var lines: [String] = []
        lines.append("ОТЧЁТ О СОСТОЯНИИ МФУ — \(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append(String(repeating: "=", count: 60))
        lines.append("Система: \(ProcessInfo.processInfo.operatingSystemVersionString)")
        lines.append("")

        lines.append("USB-УСТРОЙСТВА")
        lines.append(String(repeating: "-", count: 60))
        if usbDevices.isEmpty { lines.append("  не найдено") }
        for device in usbDevices {
            lines.append("\(device.isPanasonic ? "* " : "  ")\(device.displayName)  [\(device.vidPid)]")
            if !device.serial.isEmpty { lines.append("      серийный номер: \(device.serial)") }
            for interface in device.interfaces { lines.append("      \(interface.summary)") }
        }
        lines.append("")

        lines.append("УСТРОЙСТВА, ВИДИМЫЕ CUPS")
        lines.append(String(repeating: "-", count: 60))
        if cupsDevices.isEmpty { lines.append("  нет") }
        for device in cupsDevices {
            lines.append("  \(device.uri)")
            if !device.deviceID.isEmpty { lines.append("      device-id: \(device.deviceID)") }
        }
        lines.append("")

        lines.append("ОЧЕРЕДИ ПЕЧАТИ")
        lines.append(String(repeating: "-", count: 60))
        if printers.isEmpty { lines.append("  нет") }
        for printer in printers {
            lines.append("  \(printer.name) — \(printer.stateText)")
            lines.append("      URI: \(printer.deviceURI)")
        }
        lines.append("")

        lines.append("СКАНЕРЫ")
        lines.append(String(repeating: "-", count: 60))
        if scanners.isEmpty { lines.append("  нет") }
        for scanner in scanners { lines.append("  \(scanner.name) — \(scanner.detail)") }
        lines.append("")

        lines.append("ДРАЙВЕРЫ")
        lines.append(String(repeating: "-", count: 60))
        for status in driverStatus {
            lines.append("  [\(status.usable ? "OK" : "НЕТ")] \(status.component)")
            lines.append("      \(status.path)")
            lines.append("      \(status.detail)")
        }

        return lines.joined(separator: "\n")
    }
}
