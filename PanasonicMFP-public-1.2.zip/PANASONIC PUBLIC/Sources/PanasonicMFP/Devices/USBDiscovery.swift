import Foundation
import IOKit
import IOKit.usb

/// USB-интерфейс устройства (класс 7 = принтер, 255 = vendor-specific — как правило, сканер Panasonic).
struct USBInterfaceInfo: Hashable {
    let number: Int
    let interfaceClass: Int
    let interfaceSubClass: Int
    let interfaceProtocol: Int

    var isPrinterClass: Bool { interfaceClass == 7 }
    var isVendorSpecific: Bool { interfaceClass == 255 }

    var classDescription: String {
        switch interfaceClass {
        case 7:
            switch interfaceProtocol {
            case 1: return "Printer (однонаправленный)"
            case 2: return "Printer (двунаправленный)"
            case 3: return "Printer (IEEE-1284.4)"
            default: return "Printer"
            }
        case 255: return "Vendor-specific (скорее всего сканер)"
        case 8: return "Mass Storage"
        case 6: return "Still Image (PTP)"
        default: return "Класс \(interfaceClass)"
        }
    }

    var summary: String {
        String(format: "интерфейс %d — %@ (class %d / sub %d / proto %d)",
               number, classDescription, interfaceClass, interfaceSubClass, interfaceProtocol)
    }
}

struct USBDevice: Identifiable, Hashable {
    let vendorID: Int
    let productID: Int
    let vendorName: String
    let productName: String
    let serial: String
    let locationID: UInt32
    let deviceClass: Int
    let interfaces: [USBInterfaceInfo]

    var id: String { String(format: "%08X-%04X-%04X", locationID, vendorID, productID) }
    var isPanasonic: Bool { vendorID == USBDiscovery.panasonicVendorID }
    var vidPid: String { String(format: "0x%04X:0x%04X", vendorID, productID) }

    var displayName: String {
        if !productName.isEmpty { return productName }
        if !vendorName.isEmpty { return "\(vendorName) (\(vidPid))" }
        return vidPid
    }

    var hasPrinterInterface: Bool { interfaces.contains(where: \.isPrinterClass) }
    var hasVendorInterface: Bool { interfaces.contains(where: \.isVendorSpecific) }
}

enum USBDiscovery {
    static let panasonicVendorID = 0x04DA

    static func scan() -> [USBDevice] {
        let interfacesByLocation = scanInterfaces()
        var devices: [USBDevice] = []

        for serviceClass in ["IOUSBHostDevice", "IOUSBDevice"] {
            guard let matching = IOServiceMatching(serviceClass) else { continue }
            var iterator: io_iterator_t = 0
            guard IOServiceGetMatchingServices(kIOMainPortDefault, matching, &iterator) == KERN_SUCCESS else { continue }
            defer { IOObjectRelease(iterator) }

            while true {
                let service = IOIteratorNext(iterator)
                if service == 0 { break }
                defer { IOObjectRelease(service) }

                guard let vid = intProperty(service, "idVendor"),
                      let pid = intProperty(service, "idProduct") else { continue }

                let location = UInt32(intProperty(service, "locationID") ?? 0)
                let device = USBDevice(
                    vendorID: vid,
                    productID: pid,
                    vendorName: stringProperty(service, "USB Vendor Name") ?? "",
                    productName: stringProperty(service, "USB Product Name") ?? "",
                    serial: stringProperty(service, "USB Serial Number") ?? "",
                    locationID: location,
                    deviceClass: intProperty(service, "bDeviceClass") ?? 0,
                    interfaces: interfacesByLocation[location] ?? []
                )
                if !devices.contains(where: { $0.id == device.id }) {
                    devices.append(device)
                }
            }
            if !devices.isEmpty { break }
        }

        return devices.sorted { lhs, rhs in
            if lhs.isPanasonic != rhs.isPanasonic { return lhs.isPanasonic }
            return lhs.displayName.localizedCaseInsensitiveCompare(rhs.displayName) == .orderedAscending
        }
    }

    static func panasonicDevices() -> [USBDevice] {
        scan().filter(\.isPanasonic)
    }

    private static func scanInterfaces() -> [UInt32: [USBInterfaceInfo]] {
        var result: [UInt32: [USBInterfaceInfo]] = [:]
        for serviceClass in ["IOUSBHostInterface", "IOUSBInterface"] {
            guard let matching = IOServiceMatching(serviceClass) else { continue }
            var iterator: io_iterator_t = 0
            guard IOServiceGetMatchingServices(kIOMainPortDefault, matching, &iterator) == KERN_SUCCESS else { continue }
            defer { IOObjectRelease(iterator) }

            while true {
                let service = IOIteratorNext(iterator)
                if service == 0 { break }
                defer { IOObjectRelease(service) }

                guard let cls = intProperty(service, "bInterfaceClass") else { continue }
                let location = UInt32(intProperty(service, "locationID") ?? 0)
                let info = USBInterfaceInfo(
                    number: intProperty(service, "bInterfaceNumber") ?? 0,
                    interfaceClass: cls,
                    interfaceSubClass: intProperty(service, "bInterfaceSubClass") ?? 0,
                    interfaceProtocol: intProperty(service, "bInterfaceProtocol") ?? 0
                )
                result[location, default: []].append(info)
            }
            if !result.isEmpty { break }
        }
        for key in result.keys {
            result[key]?.sort { $0.number < $1.number }
        }
        return result
    }

    private static func property(_ service: io_object_t, _ key: String) -> Any? {
        guard let value = IORegistryEntryCreateCFProperty(service, key as CFString, kCFAllocatorDefault, 0) else {
            return nil
        }
        return value.takeRetainedValue()
    }

    private static func intProperty(_ service: io_object_t, _ key: String) -> Int? {
        guard let value = property(service, key) else { return nil }
        if let number = value as? NSNumber { return number.intValue }
        return nil
    }

    private static func stringProperty(_ service: io_object_t, _ key: String) -> String? {
        guard let value = property(service, key) else { return nil }
        if let string = value as? String { return string }
        return nil
    }
}
