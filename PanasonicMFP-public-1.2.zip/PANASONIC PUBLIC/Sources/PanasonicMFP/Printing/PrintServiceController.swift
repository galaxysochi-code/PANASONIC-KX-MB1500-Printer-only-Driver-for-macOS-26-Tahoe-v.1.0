import Foundation
import SwiftUI

/// Управление службой преобразования заданий печати (виртуальная машина colima + контейнер).
///
/// Печать на KX-MB1500 идёт через родной драйвер Panasonic для Linux, который
/// работает в контейнере. Пока служба не поднята, задания в системной очереди
/// будут завершаться ошибкой, поэтому приложение поднимает её при запуске
/// и показывает состояние в строке меню.
@MainActor
final class PrintServiceController: ObservableObject {

    enum State: Equatable {
        case unknown
        case starting
        case running
        case stopped
        case failed(String)

        var isBusy: Bool { self == .starting }

        var title: String {
            switch self {
            case .unknown: return L("Состояние неизвестно")
            case .starting: return L("Запускается…")
            case .running: return L("Служба печати работает")
            case .stopped: return L("Служба печати остановлена")
            case .failed(let message): return "Ошибка: \(message)"
            }
        }

        var symbol: String {
            switch self {
            case .running: return "printer.fill"
            case .starting: return "printer.dotmatrix"
            case .stopped, .unknown: return "printer"
            case .failed: return "exclamationmark.triangle.fill"
            }
        }

        var tint: Color {
            switch self {
            case .running: return .green
            case .starting: return .orange
            case .failed: return .red
            case .stopped, .unknown: return .secondary
            }
        }
    }

    @Published private(set) var state: State = .unknown
    @Published private(set) var detail: String = ""

    private let healthURL = URL(string: "http://127.0.0.1:9631/health")!
    private var monitorTask: Task<Void, Never>?

    /// Скрипт управления: сначала установленная копия, затем каталог исходников.
    var scriptPath: String? {
        let candidates = [
            "/Library/Printers/PanasonicMFP/panasonic-mfp-service",
            NSHomeDirectory() + "/Developer/PanasonicMFP/macos/panasonic-mfp-service",
            NSHomeDirectory() + "/Documents/PanasonicMFP/macos/panasonic-mfp-service"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    var isInstalled: Bool { scriptPath != nil }

    // MARK: - Проверка доступности

    func isHealthy() async -> Bool {
        var request = URLRequest(url: healthURL)
        request.timeoutInterval = 3
        request.cachePolicy = .reloadIgnoringLocalCacheData
        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            return (response as? HTTPURLResponse)?.statusCode == 200
        } catch {
            return false
        }
    }

    /// Поднимает службу, если она ещё не работает. Вызывается при запуске приложения.
    func ensureRunning() async {
        if await isHealthy() {
            state = .running
            detail = ""
            return
        }
        await start()
    }

    func start() async {
        guard let scriptPath else {
            state = .failed("не установлен управляющий скрипт")
            detail = "Выполните macos/install-printer.sh из каталога проекта."
            return
        }
        guard !state.isBusy else { return }

        state = .starting
        detail = "Поднимаю виртуальную машину и контейнер…"

        let result = await Shell.runAsync(scriptPath, ["start"], env: ["PATH": Self.searchPath])

        if await isHealthy() {
            state = .running
            detail = ""
        } else {
            let message = (result.err.isEmpty ? result.out : result.err)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            state = .failed(message.isEmpty ? "служба не отвечает" : String(message.suffix(300)))
            detail = message
        }
    }

    func stop() async {
        guard let scriptPath else { return }
        state = .starting
        detail = "Останавливаю службу…"
        _ = await Shell.runAsync(scriptPath, ["stop"], env: ["PATH": Self.searchPath])
        state = await isHealthy() ? .running : .stopped
        detail = ""
    }

    func restart() async {
        await stop()
        await start()
    }

    func refresh() async {
        guard !state.isBusy else { return }
        let healthy = await isHealthy()
        if healthy {
            state = .running
            detail = ""
        } else if case .failed = state {
            // не затираем текст ошибки
        } else {
            state = .stopped
        }
    }

    /// Периодическая проверка, чтобы состояние в строке меню не устаревало.
    func startMonitoring(interval: TimeInterval = 20) {
        monitorTask?.cancel()
        monitorTask = Task { [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: UInt64(interval * 1_000_000_000))
                guard let self, !Task.isCancelled else { return }
                await self.refresh()
            }
        }
    }

    func stopMonitoring() {
        monitorTask?.cancel()
        monitorTask = nil
    }

    private static let searchPath =
        "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"
}
