import Foundation

struct CUPSPrinter: Identifiable, Hashable {
    let name: String
    let info: String
    let makeAndModel: String
    let deviceURI: String
    let stateCode: Int
    let isDefault: Bool

    var id: String { name }

    var displayName: String { info.isEmpty ? name : info }

    var stateText: String {
        switch stateCode {
        case 3: return "готов"
        case 4: return "печатает"
        case 5: return "остановлен"
        default: return "состояние \(stateCode)"
        }
    }

    /// Очередь ведёт на USB-устройство Panasonic.
    var looksLikePanasonicUSB: Bool {
        let haystack = (deviceURI + " " + makeAndModel).lowercased()
        return haystack.contains("panasonic") || haystack.contains("kx-mb")
    }
}

/// Устройство, найденное самим CUPS (`lpinfo -l -v`) — включая строку IEEE-1284 device ID.
struct CUPSDiscoveredDevice: Identifiable, Hashable {
    let uri: String
    let deviceClass: String
    let info: String
    let makeAndModel: String
    let deviceID: String

    var id: String { uri }

    /// Разбор device-id: `MFG:Panasonic;CMD:PJL,PCL;MDL:KX-MB1500;`
    var deviceIDFields: [String: String] {
        var fields: [String: String] = [:]
        for chunk in deviceID.split(separator: ";") {
            let parts = chunk.split(separator: ":", maxSplits: 1).map(String.init)
            guard parts.count == 2 else { continue }
            fields[parts[0].trimmingCharacters(in: .whitespaces).uppercased()] =
                parts[1].trimmingCharacters(in: .whitespaces)
        }
        return fields
    }

    /// Список языков печати, которые заявляет само устройство.
    var commandSet: [String] {
        let fields = deviceIDFields
        let raw = fields["CMD"] ?? fields["COMMAND SET"] ?? ""
        return raw.split(separator: ",").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
    }

    var isUSB: Bool { uri.hasPrefix("usb://") }
}

enum CUPS {
    static var lp: String? { Shell.which("lp") }
    static var lpstat: String? { Shell.which("lpstat") }
    static var lpoptions: String? { Shell.which("lpoptions") }
    static var lpinfo: String? { Shell.which("lpinfo") }

    // MARK: - Очереди печати

    static func printers() -> [CUPSPrinter] {
        guard let lpstat else { return [] }

        let names = Shell.run(lpstat, ["-e"], env: Shell.cLocale).out
            .split(separator: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .filter { !$0.isEmpty }

        let defaultName = defaultPrinterName()

        return names.map { name in
            var info = ""
            var makeAndModel = ""
            var uri = ""
            var state = 0

            if let lpoptions {
                let options = Shell.parseOptions(Shell.run(lpoptions, ["-p", name], env: Shell.cLocale).out)
                info = options["printer-info"] ?? ""
                makeAndModel = options["printer-make-and-model"] ?? ""
                uri = options["device-uri"] ?? ""
                state = Int(options["printer-state"] ?? "") ?? 0
            }

            return CUPSPrinter(
                name: name,
                info: info,
                makeAndModel: makeAndModel,
                deviceURI: uri,
                stateCode: state,
                isDefault: name == defaultName
            )
        }
    }

    static func defaultPrinterName() -> String? {
        guard let lpstat else { return nil }
        let result = Shell.run(lpstat, ["-d"], env: Shell.cLocale)
        guard result.ok else { return nil }
        // "system default destination: NAME" / локализованный вариант — берём последнее слово после ':'
        guard let colon = result.out.lastIndex(of: ":") else { return nil }
        let name = result.out[result.out.index(after: colon)...].trimmingCharacters(in: .whitespacesAndNewlines)
        return name.isEmpty ? nil : name
    }

    // MARK: - Обнаружение устройств

    static func discoveredDevices() -> [CUPSDiscoveredDevice] {
        guard let lpinfo else { return [] }
        let result = Shell.run(lpinfo, ["-l", "-v"], env: Shell.cLocale)
        guard result.ok else { return [] }

        var devices: [CUPSDiscoveredDevice] = []
        var uri: String?
        var cls = "", info = "", model = "", deviceID = ""

        func flush() {
            if let uri, !uri.isEmpty, !uri.hasPrefix("file:") {
                devices.append(CUPSDiscoveredDevice(uri: uri, deviceClass: cls, info: info,
                                                    makeAndModel: model, deviceID: deviceID))
            }
            uri = nil; cls = ""; info = ""; model = ""; deviceID = ""
        }

        // Подпись «Device:» локализуется, а имена полей — нет.
        // Поэтому начало новой записи определяем по появлению «uri =».
        for rawLine in result.out.split(separator: "\n", omittingEmptySubsequences: false) {
            let trimmed = String(rawLine).trimmingCharacters(in: .whitespaces)
            if trimmed.contains("uri =") {
                flush()
                uri = value(after: "uri =", in: trimmed)
            } else if trimmed.hasPrefix("class =") {
                cls = value(after: "class =", in: trimmed) ?? ""
            } else if trimmed.hasPrefix("info =") {
                info = value(after: "info =", in: trimmed) ?? ""
            } else if trimmed.hasPrefix("make-and-model =") {
                model = value(after: "make-and-model =", in: trimmed) ?? ""
            } else if trimmed.hasPrefix("device-id =") {
                deviceID = value(after: "device-id =", in: trimmed) ?? ""
            }
        }
        flush()

        // Сетевые backend'ы CUPS перечисляет как заглушки без адреса («ipp», «lpd»…).
        // Показываем только реальные устройства.
        return devices.filter { $0.isUSB || $0.deviceClass == "direct" || $0.uri.contains("://") }
    }

    private static func value(after marker: String, in line: String) -> String? {
        guard let range = line.range(of: marker) else { return nil }
        return String(line[range.upperBound...]).trimmingCharacters(in: .whitespaces)
    }

    // MARK: - Печать

    struct PrintOptions {
        var copies: Int = 1
        var media: String = "A4"
        var sides: String = "one-sided"
        var pageRanges: String = ""
        var fitToPage: Bool = true
        var quality: String = ""          // 3 (черновик) / 4 (норм.) / 5 (высокое)
        var colorMode: String = "monochrome"
        var orientation: String = ""      // "" | "landscape"
        var title: String = ""
        var extra: [String] = []

        var lpArguments: [String] {
            var args: [String] = []
            if copies > 1 { args += ["-n", String(copies)] }
            if !title.isEmpty { args += ["-t", title] }
            if !media.isEmpty { args += ["-o", "media=\(media)"] }
            if !sides.isEmpty { args += ["-o", "sides=\(sides)"] }
            if !pageRanges.isEmpty { args += ["-o", "page-ranges=\(pageRanges)"] }
            if fitToPage { args += ["-o", "fit-to-page"] }
            if !quality.isEmpty { args += ["-o", "print-quality=\(quality)"] }
            if !colorMode.isEmpty { args += ["-o", "print-color-mode=\(colorMode)"] }
            if orientation == "landscape" { args += ["-o", "landscape"] }
            for option in extra where !option.isEmpty { args += ["-o", option] }
            return args
        }
    }

    enum PrintError: LocalizedError {
        case noLP
        case failed(String)

        var errorDescription: String? {
            switch self {
            case .noLP: return "В системе не найдена команда lp (подсистема печати CUPS)."
            case .failed(let message): return message
            }
        }
    }

    /// Отправка файла в очередь. Возвращает идентификатор задания.
    static func submit(files: [URL], to printer: String, options: PrintOptions) throws -> String {
        guard let lp else { throw PrintError.noLP }
        guard !files.isEmpty else { throw PrintError.failed("Не выбраны файлы для печати.") }

        var args = ["-d", printer]
        args += options.lpArguments
        args += files.map(\.path)

        let result = Shell.run(lp, args)
        guard result.ok else {
            let message = result.err.isEmpty ? result.out : result.err
            throw PrintError.failed(message.trimmingCharacters(in: .whitespacesAndNewlines))
        }
        return result.out.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    struct Job: Identifiable, Hashable {
        let id: String
        let user: String
        let size: String
        let date: String
    }

    static func activeJobs() -> [Job] {
        guard let lpstat else { return [] }
        let result = Shell.run(lpstat, ["-W", "not-completed", "-o"], env: Shell.cLocale)
        guard result.ok else { return [] }
        return result.out.split(separator: "\n").compactMap { line in
            let parts = line.split(separator: " ", omittingEmptySubsequences: true).map(String.init)
            guard parts.count >= 3 else { return nil }
            return Job(id: parts[0], user: parts[1], size: parts[2],
                       date: parts.dropFirst(3).joined(separator: " "))
        }
    }

    static func cancel(jobID: String) {
        guard let cancel = Shell.which("cancel") else { return }
        Shell.run(cancel, [jobID])
    }
}
