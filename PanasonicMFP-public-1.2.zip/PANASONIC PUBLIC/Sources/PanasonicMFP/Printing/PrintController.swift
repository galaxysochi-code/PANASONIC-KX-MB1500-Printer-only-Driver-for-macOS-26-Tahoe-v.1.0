import AppKit
import Foundation
import PDFKit
import UniformTypeIdentifiers

@MainActor
final class PrintController: ObservableObject {

    @Published private(set) var printers: [CUPSPrinter] = []
    @Published var selectedPrinterName: String?
    @Published var files: [URL] = []
    @Published var copies: Int = 1
    @Published var media: String = "A4"
    @Published var duplex: String = "one-sided"
    @Published var pageRanges: String = ""
    @Published var quality: String = "4"
    @Published var colorMode: String = "monochrome"
    @Published var fitToPage: Bool = true
    @Published var landscape: Bool = false

    @Published private(set) var jobs: [CUPS.Job] = []
    @Published private(set) var statusText: String = "Очередь не выбрана"
    @Published var errorMessage: String?

    static let mediaPresets = ["A4", "A5", "Letter", "Legal", "B5"]
    static let qualityPresets: [(String, String)] = [("3", "Черновик"), ("4", "Обычное"), ("5", "Высокое")]
    static let duplexPresets: [(String, String)] = [
        ("one-sided", "Односторонняя"),
        ("two-sided-long-edge", "Двусторонняя, по длинной стороне"),
        ("two-sided-short-edge", "Двусторонняя, по короткой стороне")
    ]

    var selectedPrinter: CUPSPrinter? {
        printers.first { $0.name == selectedPrinterName }
    }

    func refresh() {
        printers = CUPS.printers()
        if let selectedPrinterName, printers.contains(where: { $0.name == selectedPrinterName }) {
            // сохраняем выбор
        } else {
            selectedPrinterName = printers.first(where: \.isDefault)?.name ?? printers.first?.name
        }
        jobs = CUPS.activeJobs()

        if printers.isEmpty {
            statusText = "В системе нет ни одной очереди печати"
        } else if let printer = selectedPrinter {
            statusText = "\(printer.displayName) — \(printer.stateText)"
        }
    }

    // MARK: - Файлы

    func addFiles(_ urls: [URL]) {
        for url in urls where !files.contains(url) {
            files.append(url)
        }
    }

    func removeFiles(_ urls: Set<URL>) {
        files.removeAll { urls.contains($0) }
    }

    func clearFiles() {
        files.removeAll()
    }

    // MARK: - Печать

    func printSelectedFiles() {
        guard let printer = selectedPrinterName else {
            errorMessage = "Не выбран принтер."
            return
        }
        guard !files.isEmpty else {
            errorMessage = "Не выбраны файлы для печати."
            return
        }
        submit(files: files, to: printer, title: files.first?.lastPathComponent ?? "Документ")
    }

    func printDocument(_ urls: [URL], title: String) {
        guard let printer = selectedPrinterName else {
            errorMessage = "Не выбран принтер."
            return
        }
        submit(files: urls, to: printer, title: title)
    }

    /// Временный каталог для PDF, собранных из Word/RTF/HTML.
    private lazy var conversionDirectory: URL = {
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("PanasonicMFP-print-\(UUID().uuidString)", isDirectory: true)
        try? FileManager.default.createDirectory(at: url, withIntermediateDirectories: true)
        return url
    }()

    private func submit(files urls: [URL], to printer: String, title: String) {
        let prepared: [URL]
        do {
            let outcome = try DocumentConverter.prepareForPrinting(urls, in: conversionDirectory)
            prepared = outcome.files
            if !outcome.converted.isEmpty {
                statusText = "Преобразовано в PDF: \(outcome.converted.joined(separator: ", "))"
            }
        } catch {
            errorMessage = error.localizedDescription
            statusText = "Задание не отправлено"
            return
        }

        var options = CUPS.PrintOptions()
        options.copies = copies
        options.media = media
        options.sides = duplex
        options.pageRanges = pageRanges.trimmingCharacters(in: .whitespaces)
        options.fitToPage = fitToPage
        options.quality = quality
        options.colorMode = colorMode
        options.orientation = landscape ? "landscape" : ""
        options.title = title

        do {
            let response = try CUPS.submit(files: prepared, to: printer, options: options)
            statusText = response.isEmpty ? "Задание отправлено" : response
            errorMessage = nil
            jobs = CUPS.activeJobs()
        } catch {
            errorMessage = error.localizedDescription
            statusText = "Задание не отправлено"
        }
    }

    /// Печать через системный диалог macOS (даёт доступ ко всем настройкам драйвера).
    func printWithSystemPanel(urls: [URL]) {
        guard !urls.isEmpty else {
            errorMessage = "Нет данных для печати."
            return
        }

        let prepared: [URL]
        do {
            prepared = try DocumentConverter.prepareForPrinting(urls, in: conversionDirectory).files
        } catch {
            errorMessage = error.localizedDescription
            return
        }

        guard let first = prepared.first else { return }
        let document: PDFDocument?
        if prepared.count == 1, first.pathExtension.lowercased() == "pdf" {
            document = PDFDocument(url: first)
        } else {
            document = Self.makePDF(from: prepared)
        }

        guard let document else {
            errorMessage = "Не удалось подготовить документ для печати."
            return
        }

        let printInfo = NSPrintInfo.shared
        printInfo.horizontalPagination = .fit
        printInfo.verticalPagination = .fit
        printInfo.isHorizontallyCentered = true
        printInfo.isVerticallyCentered = true

        let operation = document.printOperation(for: printInfo, scalingMode: .pageScaleDownToFit, autoRotate: true)
        operation?.showsPrintPanel = true
        operation?.showsProgressPanel = true
        operation?.run()
    }

    /// Сборка временного PDF из набора изображений/PDF.
    static func makePDF(from urls: [URL]) -> PDFDocument? {
        let result = PDFDocument()
        var index = 0
        for url in urls {
            if url.pathExtension.lowercased() == "pdf" {
                guard let source = PDFDocument(url: url) else { continue }
                for pageIndex in 0..<source.pageCount {
                    guard let page = source.page(at: pageIndex) else { continue }
                    result.insert(page, at: index)
                    index += 1
                }
            } else if let image = NSImage(contentsOf: url), let page = PDFPage(image: image) {
                result.insert(page, at: index)
                index += 1
            }
        }
        return result.pageCount > 0 ? result : nil
    }

    func cancelJob(_ job: CUPS.Job) {
        CUPS.cancel(jobID: job.id)
        jobs = CUPS.activeJobs()
    }
}
