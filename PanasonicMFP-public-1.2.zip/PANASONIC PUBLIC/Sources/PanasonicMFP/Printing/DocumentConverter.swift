import AppKit
import Foundation
import PDFKit
import UniformTypeIdentifiers

/// Подсистема печати CUPS понимает PDF, изображения и простой текст.
/// Документы Word, RTF, ODT, HTML печатать напрямую нельзя — они сначала
/// раскладываются по страницам и превращаются в PDF средствами AppKit.
enum DocumentConverter {

    /// Форматы, которые CUPS печатает сам.
    static let directlyPrintable: Set<String> = [
        "pdf", "jpg", "jpeg", "png", "tif", "tiff", "gif", "bmp", "heic"
    ]

    /// Форматы, которые умеет прочитать AppKit и разложить по страницам.
    static let convertible: Set<String> = [
        "doc", "docx", "rtf", "rtfd", "odt", "wordml",
        "html", "htm", "webarchive", "txt", "text", "md", "markdown"
    ]

    enum ConversionError: LocalizedError {
        case unsupported(String)
        case unreadable(String, String)
        case renderFailed(String)

        var errorDescription: String? {
            switch self {
            case .unsupported(let name):
                return "Файл «\(name)» нельзя напечатать: формат не поддерживается. "
                     + "Сохраните его в PDF и добавьте снова."
            case .unreadable(let name, let reason):
                return "Не удалось прочитать «\(name)»: \(reason)"
            case .renderFailed(let name):
                return "Не удалось разложить «\(name)» по страницам."
            }
        }
    }

    static func needsConversion(_ url: URL) -> Bool {
        !directlyPrintable.contains(url.pathExtension.lowercased())
    }

    static func isKnown(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return directlyPrintable.contains(ext) || convertible.contains(ext)
    }

    /// Возвращает путь к файлу, который можно отдать в `lp`.
    /// Для PDF и изображений — исходный файл, для остальных — свежесобранный PDF.
    @MainActor
    static func printableURL(for url: URL, in directory: URL) throws -> URL {
        let ext = url.pathExtension.lowercased()
        if directlyPrintable.contains(ext) { return url }

        guard convertible.contains(ext) else {
            throw ConversionError.unsupported(url.lastPathComponent)
        }

        let attributed: NSAttributedString
        do {
            attributed = try NSAttributedString(
                url: url,
                options: [.documentType: documentType(for: ext)],
                documentAttributes: nil)
        } catch {
            // Тип мог определиться неверно — пробуем автоопределение.
            do {
                attributed = try NSAttributedString(url: url, options: [:], documentAttributes: nil)
            } catch {
                throw ConversionError.unreadable(url.lastPathComponent, error.localizedDescription)
            }
        }

        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let output = directory
            .appendingPathComponent(url.deletingPathExtension().lastPathComponent + "-\(UUID().uuidString.prefix(6)).pdf")

        try renderPDF(from: attributed, to: output)

        guard let document = PDFDocument(url: output), document.pageCount > 0 else {
            throw ConversionError.renderFailed(url.lastPathComponent)
        }
        return output
    }

    /// Пакетная подготовка: конвертирует всё, что нужно, и сообщает, что именно было сконвертировано.
    @MainActor
    static func prepareForPrinting(_ urls: [URL], in directory: URL) throws -> (files: [URL], converted: [String]) {
        var prepared: [URL] = []
        var converted: [String] = []
        for url in urls {
            let printable = try printableURL(for: url, in: directory)
            if printable != url { converted.append(url.lastPathComponent) }
            prepared.append(printable)
        }
        return (prepared, converted)
    }

    private static func documentType(for ext: String) -> NSAttributedString.DocumentType {
        switch ext {
        case "docx", "wordml": return .officeOpenXML
        case "doc": return .docFormat
        case "rtf": return .rtf
        case "rtfd": return .rtfd
        case "odt": return .openDocument
        case "html", "htm", "md", "markdown": return .html
        case "webarchive": return .webArchive
        default: return .plain
        }
    }

    /// Раскладка текста по страницам A4 и печать в файл.
    @MainActor
    private static func renderPDF(from attributed: NSAttributedString, to url: URL) throws {
        let printInfo = NSPrintInfo()
        printInfo.paperSize = NSSize(width: 595.28, height: 841.89)   // A4 в пунктах
        printInfo.topMargin = 56
        printInfo.bottomMargin = 56
        printInfo.leftMargin = 56
        printInfo.rightMargin = 56
        printInfo.horizontalPagination = .fit
        printInfo.verticalPagination = .automatic
        printInfo.isHorizontallyCentered = false
        printInfo.isVerticallyCentered = false
        printInfo.jobDisposition = .save
        printInfo.dictionary()[NSPrintInfo.AttributeKey.jobSavingURL] = url

        let contentWidth = printInfo.paperSize.width - printInfo.leftMargin - printInfo.rightMargin
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: contentWidth, height: 100))
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.textContainerInset = .zero
        textView.textContainer?.containerSize = NSSize(width: contentWidth,
                                                       height: .greatestFiniteMagnitude)
        textView.textContainer?.widthTracksTextView = true
        textView.textStorage?.setAttributedString(attributed)
        textView.sizeToFit()

        let operation = NSPrintOperation(view: textView, printInfo: printInfo)
        operation.showsPrintPanel = false
        operation.showsProgressPanel = false

        guard operation.run() else {
            throw ConversionError.renderFailed(url.lastPathComponent)
        }
    }
}
