import AppKit
import Foundation
import ImageIO
import UniformTypeIdentifiers

// MARK: - Параметры сканирования

enum ScanColorMode: String, CaseIterable, Identifiable, Codable {
    case blackAndWhite
    case grayscale
    case color

    var id: String { rawValue }

    var title: String {
        switch self {
        case .blackAndWhite: return L("Штриховой (1 бит)")
        case .grayscale: return L("Оттенки серого")
        case .color: return L("Цветной")
        }
    }

    var saneMode: String {
        switch self {
        case .blackAndWhite: return "Lineart"
        case .grayscale: return "Gray"
        case .color: return "Color"
        }
    }
}

enum ScanSource: String, CaseIterable, Identifiable, Codable {
    case flatbed
    case documentFeeder
    case documentFeederDuplex

    var id: String { rawValue }

    var title: String {
        switch self {
        case .flatbed: return L("Стекло (планшет)")
        case .documentFeeder: return L("Автоподатчик (одна сторона)")
        case .documentFeederDuplex: return L("Автоподатчик (двусторонний)")
        }
    }
}

struct PaperSize: Hashable, Identifiable, Codable {
    let name: String
    /// Ширина и высота в дюймах.
    let widthInches: Double
    let heightInches: Double

    var id: String { name }

    static let a4 = PaperSize(name: "A4", widthInches: 8.268, heightInches: 11.693)
    static let a5 = PaperSize(name: "A5", widthInches: 5.827, heightInches: 8.268)
    static let letter = PaperSize(name: "Letter", widthInches: 8.5, heightInches: 11.0)
    static let legal = PaperSize(name: "Legal", widthInches: 8.5, heightInches: 14.0)
    static let b5 = PaperSize(name: "B5", widthInches: 6.929, heightInches: 9.843)
    static let maximum = PaperSize(name: "Максимум", widthInches: 0, heightInches: 0)

    static let presets: [PaperSize] = [.a4, .letter, .a5, .b5, .legal, .maximum]

    var isMaximum: Bool { widthInches == 0 && heightInches == 0 }
}

struct ScanParameters: Codable, Hashable {
    var dpi: Int = 300
    var colorMode: ScanColorMode = .grayscale
    var source: ScanSource = .flatbed
    var paper: PaperSize = .a4
    var brightness: Double = 0      // -1000...1000 (ICA), 0 — по умолчанию
    var contrast: Double = 0

    static let dpiPresets = [100, 150, 200, 300, 400, 600, 1200]
}

// MARK: - Страница документа

struct ScanPage: Identifiable, Hashable {
    let id: UUID
    /// Файл исходного изображения (TIFF/PNG/JPEG), лежит во временном каталоге сессии.
    var fileURL: URL
    var pixelWidth: Int
    var pixelHeight: Int
    var dpi: Int
    var rotation: Int = 0            // 0 / 90 / 180 / 270, по часовой стрелке
    var thumbnail: NSImage?
    var isColor: Bool

    init(id: UUID = UUID(), fileURL: URL, pixelWidth: Int, pixelHeight: Int, dpi: Int, isColor: Bool) {
        self.id = id
        self.fileURL = fileURL
        self.pixelWidth = pixelWidth
        self.pixelHeight = pixelHeight
        self.dpi = dpi
        self.isColor = isColor
    }

    static func == (lhs: ScanPage, rhs: ScanPage) -> Bool {
        lhs.id == rhs.id && lhs.rotation == rhs.rotation && lhs.fileURL == rhs.fileURL
    }

    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
        hasher.combine(rotation)
    }

    /// Размер страницы в пунктах PDF (1/72 дюйма) с учётом поворота.
    var pageSizePoints: CGSize {
        let width = CGFloat(pixelWidth) * 72.0 / CGFloat(max(dpi, 1))
        let height = CGFloat(pixelHeight) * 72.0 / CGFloat(max(dpi, 1))
        return (rotation % 180 == 0) ? CGSize(width: width, height: height)
                                     : CGSize(width: height, height: width)
    }

    var sizeDescription: String {
        let size = pageSizePoints
        let widthMM = size.width / 72.0 * 25.4
        let heightMM = size.height / 72.0 * 25.4
        return String(format: L("%.0f×%.0f мм · %d dpi"), widthMM, heightMM, dpi)
    }

    /// Изображение страницы с применённым поворотом.
    func makeCGImage() throws -> CGImage {
        guard let source = CGImageSourceCreateWithURL(fileURL as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(source, 0, [kCGImageSourceShouldCache: false] as CFDictionary)
        else {
            throw ScanError.imageUnreadable(fileURL.lastPathComponent)
        }
        return ScanPage.rotate(image, by: rotation)
    }

    static func rotate(_ image: CGImage, by degrees: Int) -> CGImage {
        let normalized = ((degrees % 360) + 360) % 360
        guard normalized != 0 else { return image }

        let swapped = normalized % 180 != 0
        let width = swapped ? image.height : image.width
        let height = swapped ? image.width : image.height

        let colorSpace = image.colorSpace ?? CGColorSpaceCreateDeviceRGB()
        let bitmapInfo: UInt32
        let componentsColorSpace: CGColorSpace
        if colorSpace.numberOfComponents == 1 {
            componentsColorSpace = CGColorSpaceCreateDeviceGray()
            bitmapInfo = CGImageAlphaInfo.none.rawValue
        } else {
            componentsColorSpace = CGColorSpaceCreateDeviceRGB()
            bitmapInfo = CGImageAlphaInfo.noneSkipLast.rawValue
        }

        guard let context = CGContext(data: nil, width: width, height: height,
                                      bitsPerComponent: 8, bytesPerRow: 0,
                                      space: componentsColorSpace, bitmapInfo: bitmapInfo) else {
            return image
        }
        context.interpolationQuality = .high
        context.translateBy(x: CGFloat(width) / 2, y: CGFloat(height) / 2)
        context.rotate(by: -CGFloat(normalized) * .pi / 180)
        context.draw(image, in: CGRect(x: -CGFloat(image.width) / 2, y: -CGFloat(image.height) / 2,
                                       width: CGFloat(image.width), height: CGFloat(image.height)))
        return context.makeImage() ?? image
    }

    /// Создание страницы из файла: читает размеры и разрешение из метаданных.
    static func load(from url: URL, fallbackDPI: Int) -> ScanPage? {
        guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
              let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any]
        else { return nil }

        let width = properties[kCGImagePropertyPixelWidth] as? Int ?? 0
        let height = properties[kCGImagePropertyPixelHeight] as? Int ?? 0
        guard width > 0, height > 0 else { return nil }

        var dpi = fallbackDPI
        if let dpiWidth = properties[kCGImagePropertyDPIWidth] as? Double, dpiWidth > 1 {
            dpi = Int(dpiWidth.rounded())
        } else if let tiff = properties[kCGImagePropertyTIFFDictionary] as? [CFString: Any],
                  let xres = tiff[kCGImagePropertyTIFFXResolution] as? Double, xres > 1 {
            dpi = Int(xres.rounded())
        }

        let colorModel = properties[kCGImagePropertyColorModel] as? String
        let isColor = colorModel == (kCGImagePropertyColorModelRGB as String)

        var page = ScanPage(fileURL: url, pixelWidth: width, pixelHeight: height, dpi: dpi, isColor: isColor)
        page.thumbnail = makeThumbnail(source: source, maxPixel: 480)
        return page
    }

    static func makeThumbnail(source: CGImageSource, maxPixel: Int) -> NSImage? {
        let options: [CFString: Any] = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxPixel
        ]
        guard let cgImage = CGImageSourceCreateThumbnailAtIndex(source, 0, options as CFDictionary) else {
            return nil
        }
        return NSImage(cgImage: cgImage, size: NSSize(width: cgImage.width, height: cgImage.height))
    }

    mutating func refreshThumbnail() {
        guard let source = CGImageSourceCreateWithURL(fileURL as CFURL, nil) else { return }
        guard let base = ScanPage.makeThumbnail(source: source, maxPixel: 480) else { return }
        if rotation % 360 == 0 {
            thumbnail = base
            return
        }
        if let cgImage = base.cgImage(forProposedRect: nil, context: nil, hints: nil) {
            let rotated = ScanPage.rotate(cgImage, by: rotation)
            thumbnail = NSImage(cgImage: rotated, size: NSSize(width: rotated.width, height: rotated.height))
        }
    }
}

// MARK: - Ошибки

enum ScanError: LocalizedError {
    case noDevice
    case sessionFailed(String)
    case functionalUnitUnavailable(ScanSource)
    case scanFailed(String)
    case cancelled
    case imageUnreadable(String)
    case backendMissing(String)

    var errorDescription: String? {
        switch self {
        case .noDevice:
            return L("Сканер не выбран или не найден в системе.")
        case .sessionFailed(let message):
            return "Не удалось открыть сессию со сканером: \(message)"
        case .functionalUnitUnavailable(let source):
            return "Устройство не поддерживает источник «\(source.title)»."
        case .scanFailed(let message):
            return "Ошибка сканирования: \(message)"
        case .cancelled:
            return L("Сканирование отменено.")
        case .imageUnreadable(let name):
            return "Не удалось прочитать изображение \(name)."
        case .backendMissing(let name):
            return "Не установлен компонент \(name)."
        }
    }
}

// Описание сканера — в Devices/ScannerRef.swift: оно нужно и разделу
// диагностики, где сканирование ещё не при чём.
