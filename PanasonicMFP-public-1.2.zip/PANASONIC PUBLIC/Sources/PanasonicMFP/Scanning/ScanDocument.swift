import AppKit
import Foundation

/// Накопитель страниц текущей сессии сканирования.
/// Именно он обеспечивает «несколько страниц — один файл»: страницы копятся здесь,
/// а затем выгружаются одним документом.
@MainActor
final class ScanDocument: ObservableObject {

    @Published var pages: [ScanPage] = []
    @Published var title: String = "Документ"
    @Published var selection: Set<ScanPage.ID> = []

    /// Временный каталог сессии, чистится при выходе из приложения.
    let workDirectory: URL

    init() {
        let base = FileManager.default.temporaryDirectory
            .appendingPathComponent("PanasonicMFP", isDirectory: true)
            .appendingPathComponent(UUID().uuidString, isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        workDirectory = base
    }

    var isEmpty: Bool { pages.isEmpty }
    var pageCount: Int { pages.count }

    var summary: String {
        guard !pages.isEmpty else { return L("Страниц нет") }
        let dpiSet = Set(pages.map(\.dpi))
        let dpiText = dpiSet.count == 1 ? "\(dpiSet.first!) dpi" : "смешанное разрешение"
        return "\(pageCount) \(Self.pluralPages(pageCount)) · \(dpiText)"
    }

    static func pluralPages(_ count: Int) -> String {
        let mod100 = count % 100
        let mod10 = count % 10
        if mod100 >= 11 && mod100 <= 14 { return L("страниц") }
        switch mod10 {
        case 1: return L("страница")
        case 2, 3, 4: return L("страницы")
        default: return L("страниц")
        }
    }

    // MARK: - Изменение состава

    @discardableResult
    func append(contentsOf urls: [URL], fallbackDPI: Int) -> Int {
        var added = 0
        for url in urls {
            guard let page = ScanPage.load(from: url, fallbackDPI: fallbackDPI) else { continue }
            pages.append(page)
            added += 1
        }
        return added
    }

    /// Импорт готовых изображений или PDF, лежащих на диске (файлы копируются в каталог сессии).
    @discardableResult
    func importFiles(_ urls: [URL], fallbackDPI: Int) -> Int {
        var imported: [URL] = []
        for url in urls {
            let destination = workDirectory.appendingPathComponent(UUID().uuidString + "-" + url.lastPathComponent)
            do {
                try FileManager.default.copyItem(at: url, to: destination)
                imported.append(destination)
            } catch {
                continue
            }
        }
        return append(contentsOf: imported, fallbackDPI: fallbackDPI)
    }

    func remove(ids: Set<ScanPage.ID>) {
        pages.removeAll { ids.contains($0.id) }
        selection.subtract(ids)
    }

    func removeAll() {
        pages.removeAll()
        selection.removeAll()
    }

    func rotate(ids: Set<ScanPage.ID>, by degrees: Int) {
        for index in pages.indices where ids.contains(pages[index].id) {
            pages[index].rotation = (((pages[index].rotation + degrees) % 360) + 360) % 360
            pages[index].refreshThumbnail()
        }
    }

    func move(fromOffsets source: IndexSet, toOffset destination: Int) {
        pages.move(fromOffsets: source, toOffset: destination)
    }

    func movePage(id: ScanPage.ID, by delta: Int) {
        guard let index = pages.firstIndex(where: { $0.id == id }) else { return }
        let target = index + delta
        guard target >= 0, target < pages.count else { return }
        pages.swapAt(index, target)
    }

    func duplicate(ids: Set<ScanPage.ID>) {
        let copies = pages.filter { ids.contains($0.id) }
        for original in copies {
            var copy = original
            copy = ScanPage(fileURL: original.fileURL,
                            pixelWidth: original.pixelWidth,
                            pixelHeight: original.pixelHeight,
                            dpi: original.dpi,
                            isColor: original.isColor)
            copy.rotation = original.rotation
            copy.thumbnail = original.thumbnail
            pages.append(copy)
        }
    }

    func cleanup() {
        try? FileManager.default.removeItem(at: workDirectory)
    }
}
