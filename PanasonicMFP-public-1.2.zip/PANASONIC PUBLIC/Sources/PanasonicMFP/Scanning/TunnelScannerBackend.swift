import Foundation

/// Сканирование через USB-тоннель.
///
/// Родной SANE-бэкенд Panasonic существует только для Linux, а ImageCapture-модуль
/// на современной macOS не загружается. Поэтому бэкенд работает в контейнере, его
/// обращения к libusb перехватывает прослойка и по TCP передаёт мосту на стороне
/// macOS, а тот говорит с аппаратом через IOKit:
///
///     scanimage (контейнер) -> libsane Panasonic -> прослойка libusb-0.1
///        -> TCP 9632 -> usbbridge (macOS) -> IOKit -> KX-MB1500
///
/// Мост поднимается на время операции и сразу гасится: пока он живёт, он может
/// открыть аппарат монопольно и помешать печати.
@MainActor
final class TunnelScannerBackend: ObservableObject {

    static let shared = TunnelScannerBackend()

    private static let image = "panasonic-mfp-scanner"
    private static let bridgePort: UInt16 = 9632
    /// Каталог обмена с контейнером обязан лежать внутри домашнего каталога:
    /// виртуальная машина colima монтирует только его, временный каталог macOS ей не виден.
    private static let exchangeDirectory = FileManager.default
        .homeDirectoryForCurrentUser
        .appendingPathComponent("Library/Application Support/PanasonicMFP/tunnel", isDirectory: true)

    private var bridgeProcess: Process?

    private init() {}

    // MARK: - Наличие составных частей

    static var dockerPath: String? { Shell.which("docker") }

    /// Мост: сначала установленная копия, затем сборка из каталога проекта.
    static var bridgePath: String? {
        let candidates = [
            "/Library/Printers/PanasonicMFP/usbbridge",
            NSHomeDirectory() + "/Developer/PanasonicMFP/build/usbbridge"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    /// Скрипт службы: он умеет скачать драйвер сканера с сайта Panasonic,
    /// проверить контрольную сумму и собрать образ.
    static var servicePath: String? {
        let candidates = [
            "/Users/Shared/PanasonicMFP/panasonic-mfp-service",
            NSHomeDirectory() + "/Developer/PanasonicMFP/macos/panasonic-mfp-service"
        ]
        return candidates.first { FileManager.default.isExecutableFile(atPath: $0) }
    }

    static var isAvailable: Bool { dockerPath != nil && bridgePath != nil && servicePath != nil }

    /// Причина, по которой тоннель недоступен, — для показа в разделе «Устройство».
    static var unavailableReason: String? {
        if dockerPath == nil { return L("не найден docker (нужны colima и docker)") }
        if bridgePath == nil { return L("не установлен USB-мост") }
        if servicePath == nil { return L("не установлен управляющий скрипт") }
        return nil
    }

    // MARK: - Мост

    private func startBridge() throws {
        if let process = bridgeProcess, process.isRunning { return }
        guard let path = Self.bridgePath else {
            throw ScanError.backendMissing("USB-мост (usbbridge)")
        }

        let process = Process()
        process.executableURL = URL(fileURLWithPath: path)
        let log = FileHandle(forWritingAtPath: "/tmp/panasonic-usbbridge.log")
            ?? { FileManager.default.createFile(atPath: "/tmp/panasonic-usbbridge.log", contents: nil)
                 return FileHandle(forWritingAtPath: "/tmp/panasonic-usbbridge.log") }()
        if let log {
            log.seekToEndOfFile()
            process.standardOutput = log
            process.standardError = log
        }
        try process.run()
        bridgeProcess = process
    }

    private func stopBridge() {
        guard let process = bridgeProcess else { return }
        if process.isRunning { process.terminate() }
        bridgeProcess = nil
    }

    /// Поднимает мост, выполняет операцию, гасит мост.
    private func withBridge<T>(_ body: () async throws -> T) async throws -> T {
        try startBridge()
        defer { stopBridge() }

        // Ждём, пока мост займёт порт: обычно это доли секунды.
        var attempts = 0
        while !Self.isPortOpen(Self.bridgePort) && attempts < 30 {
            try? await Task.sleep(nanoseconds: 100_000_000)
            attempts += 1
        }
        guard Self.isPortOpen(Self.bridgePort) else {
            throw ScanError.scanFailed("USB-мост не отвечает на порту \(Self.bridgePort)")
        }

        return try await body()
    }

    private static func isPortOpen(_ port: UInt16) -> Bool {
        let handle = socket(AF_INET, SOCK_STREAM, 0)
        guard handle >= 0 else { return false }
        defer { close(handle) }

        var address = sockaddr_in()
        address.sin_family = sa_family_t(AF_INET)
        address.sin_port = port.bigEndian
        address.sin_addr.s_addr = inet_addr("127.0.0.1")

        let result = withUnsafePointer(to: &address) { pointer in
            pointer.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                connect(handle, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
            }
        }
        return result == 0
    }

    // MARK: - Образ контейнера

    /// Сообщение о длительной подготовке (сборка образа), чтобы интерфейс не молчал.
    @Published private(set) var preparationStatus: String?

    private var imageChecked = false

    /// Образ собирается при первом обращении. В установочный пакет он не входит:
    /// драйвер сканера Panasonic распространяет сам производитель, поэтому скрипт
    /// службы скачивает его с официального сайта, сверяет SHA-256 и собирает образ.
    private func ensureImage() async throws {
        guard let docker = Self.dockerPath else { throw ScanError.backendMissing("docker") }
        if imageChecked { return }

        let inspect = await Shell.runAsync(docker, ["image", "inspect", Self.image])
        if inspect.ok {
            imageChecked = true
            return
        }

        guard let service = Self.servicePath else {
            throw ScanError.backendMissing(L("управляющий скрипт службы"))
        }

        preparationStatus = L("Готовлю сканер: загружаю драйвер и собираю контейнер…")
        defer { preparationStatus = nil }

        let result = await Shell.runAsync(service, ["scanner-setup"],
                                          env: ["PATH": Self.searchPath])
        guard result.ok else {
            let message = (result.err.isEmpty ? result.out : result.err)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            throw ScanError.scanFailed(L("не удалось подготовить сканер") + ": "
                                       + String(message.suffix(300)))
        }
        imageChecked = true
    }

    private static let searchPath =
        "/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

    // MARK: - Запуск контейнера

    /// Общая часть команды. Вместо оболочки подставляется `timeout`, поэтому
    /// аргументы передаются списком и не нуждаются в экранировании.
    private static func dockerArguments(seconds: Int, mountExchange: Bool) -> [String] {
        var args = ["run", "--rm", "--platform", "linux/amd64",
                    "--add-host=host.docker.internal:host-gateway"]
        if mountExchange {
            args += ["-v", "\(exchangeDirectory.path):/out"]
        }
        args += ["--entrypoint", "/usr/bin/timeout", image, String(seconds), "/usr/bin/scanimage"]
        return args
    }

    // MARK: - Список устройств

    func devices() async -> [ScannerRef] {
        guard Self.isAvailable, let docker = Self.dockerPath else { return [] }

        let result: CommandResult
        do {
            try await ensureImage()
            result = try await withBridge {
                await Shell.runAsync(docker, Self.dockerArguments(seconds: 60, mountExchange: false) + ["-L"])
            }
        } catch {
            return []
        }

        var refs: [ScannerRef] = []
        for line in result.out.split(separator: "\n") {
            // Формат: device `libusb:001:001' is a Panasonic KX-MB1500RU sheetfed scanner
            guard let openQuote = line.firstIndex(of: "`"),
                  let closeQuote = line.firstIndex(of: "'"),
                  openQuote < closeQuote else { continue }
            let identifier = String(line[line.index(after: openQuote)..<closeQuote])
            var name = String(line[line.index(after: closeQuote)...])
                .trimmingCharacters(in: .whitespaces)
            if name.hasPrefix("is a ") { name = String(name.dropFirst(5)) }
            refs.append(ScannerRef(id: identifier,
                                   name: name.isEmpty ? identifier : name,
                                   detail: "USB-мост · \(identifier)",
                                   backend: .tunnel))
        }
        return refs
    }

    // MARK: - Сканирование

    func scan(deviceID: String, parameters: ScanParameters, into directory: URL) async throws -> [URL] {
        guard let docker = Self.dockerPath else {
            throw ScanError.backendMissing("docker")
        }
        try await ensureImage()
        try FileManager.default.createDirectory(at: Self.exchangeDirectory, withIntermediateDirectories: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)

        let name = "scan-\(Int(Date().timeIntervalSince1970)).png"

        // PNG, а не TIFF: scanimage в образе собран без libtiff.
        var arguments = Self.dockerArguments(seconds: 600, mountExchange: true)
        arguments += ["-d", deviceID,
                      "--mode", Self.panasonicMode(parameters.colorMode),
                      "--resolution", String(parameters.dpi),
                      "--format=png",
                      "-o", "/out/\(name)"]

        if !parameters.paper.isMaximum {
            arguments += ["-l", "0", "-t", "0",
                          "-x", String(format: "%.1f", parameters.paper.widthInches * 25.4),
                          "-y", String(format: "%.1f", parameters.paper.heightInches * 25.4)]
        }

        let result = try await withBridge {
            await Shell.runAsync(docker, arguments)
        }

        let produced = Self.exchangeDirectory.appendingPathComponent(name)
        guard FileManager.default.fileExists(atPath: produced.path) else {
            throw ScanError.scanFailed(Self.errorText(result))
        }

        // Файл переносится в рабочий каталог документа, каталог обмена остаётся пустым.
        let destination = directory.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: destination)
        try FileManager.default.moveItem(at: produced, to: destination)
        return [destination]
    }

    /// Названия режимов у бэкенда Panasonic отличаются от принятых в SANE
    /// (`Lineart`/`Gray`/`Color`).
    private static func panasonicMode(_ mode: ScanColorMode) -> String {
        switch mode {
        case .blackAndWhite: return "Black and White"
        case .grayscale: return "Grayscale"
        case .color: return "Color"
        }
    }

    private static func errorText(_ result: CommandResult) -> String {
        let text = (result.err.isEmpty ? result.out : result.err)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if result.status == 124 {
            return "сканирование не уложилось в отведённое время"
        }
        return text.isEmpty ? "scanimage завершился с кодом \(result.status)" : text
    }
}
