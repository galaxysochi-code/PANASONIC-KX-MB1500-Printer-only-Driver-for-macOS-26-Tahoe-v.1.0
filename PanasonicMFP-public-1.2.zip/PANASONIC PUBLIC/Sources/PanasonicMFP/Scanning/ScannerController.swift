import Combine
import Foundation

/// Управление сканированием.
///
/// Путь один — USB-тоннель. Штатный ImageCapture для KX-MB1500 неработоспособен:
/// модуль Panasonic не загружается на современных macOS, а универсального
/// драйвера у аппарата нет.
@MainActor
final class ScannerController: ObservableObject {

    @Published private(set) var scanners: [ScannerRef] = []
    @Published var selectedScannerID: String?
    @Published var parameters = ScanParameters()
    @Published private(set) var isScanning = false
    @Published private(set) var isRefreshing = false
    @Published private(set) var statusText = L("Устройство не выбрано")
    @Published var errorMessage: String?
    @Published private(set) var availableResolutions: [Int] = ScanParameters.dpiPresets
    @Published private(set) var availableSources: [ScanSource] = [.flatbed]
    @Published private(set) var tunnelAvailable = TunnelScannerBackend.isAvailable

    let tunnel = TunnelScannerBackend.shared
    private var cancellables = Set<AnyCancellable>()

    init() {
        // Долгая подготовка (сборка контейнера) должна быть видна в интерфейсе.
        tunnel.$preparationStatus
            .compactMap { $0 }
            .receive(on: RunLoop.main)
            .sink { [weak self] text in self?.statusText = text }
            .store(in: &cancellables)
    }

    var selectedScanner: ScannerRef? {
        scanners.first { $0.id == selectedScannerID }
    }

    // MARK: - Обновление списка

    func refresh() async {
        isRefreshing = true
        defer { isRefreshing = false }

        tunnelAvailable = TunnelScannerBackend.isAvailable
        guard tunnelAvailable else {
            scanners = []
            statusText = TunnelScannerBackend.unavailableReason.map {
                L("Сканирование недоступно") + ": " + $0
            } ?? L("Сканер не найден")
            return
        }

        statusText = L("Опрашиваю USB-мост…")
        scanners = await tunnel.devices()

        if let selectedScannerID, scanners.contains(where: { $0.id == selectedScannerID }) {
            // выбор сохраняем
        } else {
            selectedScannerID = scanners.first?.id
        }
        updateCapabilities()
        statusText = scanners.isEmpty
            ? L("Сканер не найден")
            : L("Найдено устройств") + ": \(scanners.count)"
    }

    func updateCapabilities() {
        // KX-MB1500 — чисто планшетный аппарат: автоподатчика нет,
        // в опциях бэкенда выбора источника тоже нет.
        availableSources = [.flatbed]
        availableResolutions = [75] + ScanParameters.dpiPresets

        if !availableSources.contains(parameters.source) {
            parameters.source = availableSources.first ?? .flatbed
        }
        if !availableResolutions.contains(parameters.dpi) {
            parameters.dpi = availableResolutions.min(by: {
                abs($0 - parameters.dpi) < abs($1 - parameters.dpi)
            }) ?? parameters.dpi
        }
    }

    // MARK: - Сканирование

    /// Сканирует и добавляет полученные страницы в документ.
    @discardableResult
    func scanAppending(to document: ScanDocument) async -> Int {
        guard let scanner = selectedScanner else {
            errorMessage = ScanError.noDevice.localizedDescription
            return 0
        }
        guard !isScanning else { return 0 }

        isScanning = true
        errorMessage = nil
        statusText = L("Сканирование…")
        defer { isScanning = false }

        do {
            let urls = try await tunnel.scan(deviceID: scanner.id,
                                             parameters: parameters,
                                             into: document.workDirectory)
            let added = document.append(contentsOf: urls, fallbackDPI: parameters.dpi)
            statusText = added > 0
                ? L("Добавлено страниц") + ": \(added)"
                : L("Устройство не вернуло изображений")
            return added
        } catch {
            errorMessage = error.localizedDescription
            statusText = L("Ошибка")
            return 0
        }
    }

    func cancel() {
        statusText = L("Отмена…")
    }
}
