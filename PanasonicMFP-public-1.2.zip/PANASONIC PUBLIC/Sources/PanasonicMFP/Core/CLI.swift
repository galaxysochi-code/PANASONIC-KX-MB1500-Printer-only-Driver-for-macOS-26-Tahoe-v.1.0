import Foundation
import ImageCaptureCore

/// Служебный режим запуска из терминала: `--report`.
enum CLI {

    static func printReport() {
        var lines: [String] = []
        lines.append("ОТЧЁТ О СОСТОЯНИИ МФУ — \(Date().formatted(date: .abbreviated, time: .standard))")
        lines.append(String(repeating: "=", count: 64))
        lines.append("Система: \(ProcessInfo.processInfo.operatingSystemVersionString)")
        lines.append("")

        lines.append("USB-УСТРОЙСТВА")
        lines.append(String(repeating: "-", count: 64))
        let usb = USBDiscovery.scan()
        if usb.isEmpty { lines.append("  не найдено") }
        for device in usb {
            lines.append("\(device.isPanasonic ? "* " : "  ")\(device.displayName)  [\(device.vidPid)]")
            if !device.serial.isEmpty { lines.append("      серийный номер: \(device.serial)") }
            lines.append(String(format: "      locationID: 0x%08X, класс: %d", device.locationID, device.deviceClass))
            for interface in device.interfaces { lines.append("      \(interface.summary)") }
        }
        lines.append("")

        lines.append("УСТРОЙСТВА, ВИДИМЫЕ CUPS")
        lines.append(String(repeating: "-", count: 64))
        let cupsDevices = CUPS.discoveredDevices()
        if cupsDevices.isEmpty { lines.append("  нет") }
        for device in cupsDevices {
            lines.append("  \(device.uri)")
            if !device.makeAndModel.isEmpty { lines.append("      модель: \(device.makeAndModel)") }
            if !device.deviceID.isEmpty { lines.append("      device-id: \(device.deviceID)") }
            if !device.commandSet.isEmpty {
                lines.append("      языки печати: \(device.commandSet.joined(separator: ", "))")
            }
        }
        lines.append("")

        lines.append("ОЧЕРЕДИ ПЕЧАТИ")
        lines.append(String(repeating: "-", count: 64))
        let printers = CUPS.printers()
        if printers.isEmpty { lines.append("  нет") }
        for printer in printers {
            lines.append("  \(printer.name) — \(printer.makeAndModel.isEmpty ? "без модели" : printer.makeAndModel)")
            lines.append("      URI: \(printer.deviceURI), состояние: \(printer.stateText)")
        }
        lines.append("")

        lines.append("СКАНЕРЫ, ВИДИМЫЕ ImageCapture")
        lines.append(String(repeating: "-", count: 64))
        let scanners = browseScanners(timeout: 3.0)
        if scanners.isEmpty { lines.append("  нет") }
        for scanner in scanners { lines.append("  \(scanner.name) — \(scanner.detail)") }
        lines.append("")

        lines.append("ШТАТНЫЕ ДРАЙВЕРЫ PANASONIC")
        lines.append(String(repeating: "-", count: 64))
        for status in Diagnostics.collectDriverStatus() {
            lines.append("  [\(status.usable ? "OK " : "НЕТ")] \(status.component)")
            lines.append("        \(status.detail)")
        }

        print(lines.joined(separator: "\n"))
    }

    /// Проверка USB-тоннеля на живом аппарате, минуя интерфейс: сканирует
    /// `pages` страниц и собирает их в один PDF.
    static func testTunnel(pages: Int, dpi: Int) -> Bool {
        var finished = false
        var success = false

        Task { @MainActor in
            defer { finished = true }

            if let reason = TunnelScannerBackend.unavailableReason {
                print("Тоннель недоступен: \(reason)")
                return
            }

            let backend = TunnelScannerBackend.shared
            let devices = await backend.devices()
            print("Найдено устройств: \(devices.count)")
            for device in devices { print("  \(device.id) — \(device.name)") }
            guard let device = devices.first else { return }

            let document = ScanDocument()
            var parameters = ScanParameters()
            parameters.dpi = dpi
            parameters.colorMode = .grayscale
            parameters.paper = .a4

            for index in 1...max(pages, 1) {
                print("Сканирую страницу \(index) из \(pages)…")
                do {
                    let urls = try await backend.scan(deviceID: device.id,
                                                      parameters: parameters,
                                                      into: document.workDirectory)
                    let added = document.append(contentsOf: urls, fallbackDPI: dpi)
                    print("  добавлено страниц: \(added), всего: \(document.pageCount)")
                } catch {
                    print("  ошибка: \(error.localizedDescription)")
                    return
                }
            }

            var settings = ExportSettings()
            settings.format = .pdf
            settings.documentTitle = "Проверка тоннеля"
            let destination = FileManager.default.temporaryDirectory
                .appendingPathComponent("panasonic-tunnel-test.pdf")

            do {
                _ = try await DocumentExporter.export(
                    pages: document.pages.map {
                        ExportPage(fileURL: $0.fileURL, rotation: $0.rotation, dpi: $0.dpi)
                    },
                    settings: settings,
                    to: destination)
                print("PDF собран: \(destination.path)")
                success = document.pageCount == max(pages, 1)
            } catch {
                print("Ошибка сборки PDF: \(error.localizedDescription)")
            }
        }

        // Главный поток нужен живым: работа идёт на @MainActor.
        while !finished && RunLoop.current.run(mode: .default, before: .distantFuture) {}
        return success
    }

    /// Кратковременный обход ImageCapture без графического интерфейса.
    static func browseScanners(timeout: TimeInterval) -> [ScannerRef] {
        let collector = ScannerCollector()
        let browser = ICDeviceBrowser()
        browser.delegate = collector
        if let mask = ICDeviceTypeMask(rawValue:
            ICDeviceTypeMask.scanner.rawValue |
            ICDeviceLocationTypeMask.local.rawValue |
            ICDeviceLocationTypeMask.shared.rawValue |
            ICDeviceLocationTypeMask.bonjour.rawValue) {
            browser.browsedDeviceTypeMask = mask
        }
        browser.start()
        RunLoop.current.run(until: Date().addingTimeInterval(timeout))
        browser.stop()
        return collector.found
    }

    private final class ScannerCollector: NSObject, ICDeviceBrowserDelegate {
        var found: [ScannerRef] = []

        func deviceBrowser(_ browser: ICDeviceBrowser, didAdd device: ICDevice, moreComing: Bool) {
            guard let scanner = device as? ICScannerDevice else { return }
            found.append(ScannerRef(
                id: scanner.uuidString ?? UUID().uuidString,
                name: scanner.name ?? "без имени",
                detail: String(format: "USB %04X:%04X", scanner.usbVendorID, scanner.usbProductID)))
        }

        func deviceBrowser(_ browser: ICDeviceBrowser, didRemove device: ICDevice, moreGoing: Bool) {}
    }
}
