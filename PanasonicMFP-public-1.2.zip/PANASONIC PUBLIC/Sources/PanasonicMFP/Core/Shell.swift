import Foundation

struct CommandResult {
    let status: Int32
    let out: String
    let err: String
    var ok: Bool { status == 0 }
}

enum Shell {
    /// Окружение, принудительно включающее английский вывод.
    /// Утилиты CUPS локализуют подписи полей, и разбирать локализованный текст нельзя.
    static let cLocale = ["LC_ALL": "C", "LANG": "C"]

    /// Синхронный запуск процесса с раздельным чтением stdout/stderr (без риска взаимной блокировки).
    @discardableResult
    static func run(_ path: String, _ args: [String], stdin: Data? = nil,
                    env: [String: String]? = nil) -> CommandResult {
        guard FileManager.default.isExecutableFile(atPath: path) else {
            return CommandResult(status: -1, out: "", err: "Не найдена программа \(path)")
        }

        let process = Process()
        process.executableURL = URL(fileURLWithPath: path)
        process.arguments = args
        if let env {
            process.environment = ProcessInfo.processInfo.environment.merging(env) { _, new in new }
        }

        let outPipe = Pipe()
        let errPipe = Pipe()
        process.standardOutput = outPipe
        process.standardError = errPipe
        let inPipe: Pipe? = stdin != nil ? Pipe() : nil
        if let inPipe { process.standardInput = inPipe }

        do {
            try process.run()
        } catch {
            return CommandResult(status: -1, out: "", err: error.localizedDescription)
        }

        if let inPipe, let data = stdin {
            inPipe.fileHandleForWriting.write(data)
            try? inPipe.fileHandleForWriting.close()
        }

        let lock = NSLock()
        var outData = Data()
        var errData = Data()
        let group = DispatchGroup()

        group.enter()
        DispatchQueue.global(qos: .userInitiated).async {
            let data = outPipe.fileHandleForReading.readDataToEndOfFile()
            lock.lock(); outData = data; lock.unlock()
            group.leave()
        }
        group.enter()
        DispatchQueue.global(qos: .userInitiated).async {
            let data = errPipe.fileHandleForReading.readDataToEndOfFile()
            lock.lock(); errData = data; lock.unlock()
            group.leave()
        }

        process.waitUntilExit()
        group.wait()

        return CommandResult(
            status: process.terminationStatus,
            out: String(decoding: outData, as: UTF8.self),
            err: String(decoding: errData, as: UTF8.self)
        )
    }

    static func runAsync(_ path: String, _ args: [String], stdin: Data? = nil,
                         env: [String: String]? = nil) async -> CommandResult {
        await withCheckedContinuation { continuation in
            DispatchQueue.global(qos: .userInitiated).async {
                continuation.resume(returning: run(path, args, stdin: stdin, env: env))
            }
        }
    }

    /// Поиск исполняемого файла в типовых каталогах (включая Homebrew на Apple Silicon).
    static func which(_ name: String) -> String? {
        let dirs = ["/usr/bin", "/bin", "/usr/sbin", "/sbin",
                    "/opt/homebrew/bin", "/opt/homebrew/sbin",
                    "/usr/local/bin", "/usr/local/sbin"]
        for dir in dirs {
            let path = "\(dir)/\(name)"
            if FileManager.default.isExecutableFile(atPath: path) { return path }
        }
        return nil
    }

    /// Разбор строки вида `key=value key2='value with spaces'` (формат вывода lpoptions).
    static func parseOptions(_ line: String) -> [String: String] {
        var result: [String: String] = [:]
        var key = ""
        var value = ""
        var readingKey = true
        var quote: Character?
        var iterator = line.makeIterator()

        func flush() {
            let trimmedKey = key.trimmingCharacters(in: .whitespaces)
            if !trimmedKey.isEmpty { result[trimmedKey] = value }
            key = ""; value = ""; readingKey = true
        }

        while let ch = iterator.next() {
            if let q = quote {
                if ch == q { quote = nil } else { value.append(ch) }
                continue
            }
            switch ch {
            case "'", "\"":
                if readingKey { readingKey = false }
                quote = ch
            case "=" where readingKey:
                readingKey = false
            case " ", "\t", "\n":
                flush()
            default:
                if readingKey { key.append(ch) } else { value.append(ch) }
            }
        }
        flush()
        return result
    }
}
