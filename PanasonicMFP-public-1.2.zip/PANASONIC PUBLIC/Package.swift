// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "PanasonicMFP",
    platforms: [.macOS(.v15)],
    products: [
        .executable(name: "PanasonicMFP", targets: ["PanasonicMFP"])
    ],
    targets: [
        .executableTarget(
            name: "PanasonicMFP",
            path: "Sources/PanasonicMFP",
            swiftSettings: [.swiftLanguageMode(.v5)]
        )
    ]
)
