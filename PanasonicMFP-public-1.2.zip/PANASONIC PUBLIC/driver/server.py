#!/usr/bin/env python3
"""Служба преобразования заданий печати для Panasonic KX-MB1500.

Принимает PDF по HTTP и возвращает поток PJL/GDI, готовый для отправки в аппарат.

Почему именно служба, а не разовый запуск контейнера: фильтры CUPS на macOS
выполняются от пользователя _lp, у которого нет доступа к Docker. Зато сетевое
соединение на localhost ему доступно, поэтому контейнер работает постоянно.

CUPS поднимается один раз при старте: фильтр Panasonic запрашивает настройки
через cupsGetPPD и без работающего демона падает с «ERROR in InitCupsOptions».
"""
import http.server
import os
import shlex
import subprocess
import sys
import threading
import time

PORT = int(os.environ.get("PORT", "9631"))
MODEL = os.environ.get("MODEL", "MB1500")
# Общий секрет с бэкендом печати. Порт слушается только на 127.0.0.1, а токен
# дополнительно закрывает службу от других учётных записей той же машины.
TOKEN = os.environ.get("PANASONIC_TOKEN", "")
QUEUE = "KXMB"
OUTPUT_FILE = "/tmp/out.prn"
INPUT_FILE = "/tmp/in.pdf"
PPD_FILE = f"/usr/share/ppd/panasonic/L_Panasonic-{MODEL}-gdi.ppd"

# Пропускаем только те параметры, которые понимает PPD Panasonic.
ALLOWED_OPTIONS = {
    "PageSize", "PageRegion", "Resolution", "MediaType", "InputSlot",
    "Duplex", "TonerSave", "Halftone", "Collate", "PrintQuality",
}

_lock = threading.Lock()


def log(message):
    print(f"[panasonic] {message}", file=sys.stderr, flush=True)


def wait_for_cups(timeout=15.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        if subprocess.run(["lpstat", "-r"], capture_output=True).returncode == 0:
            return True
        time.sleep(0.2)
    return False


def start_cups():
    if not os.path.isfile(PPD_FILE):
        raise SystemExit(f"не найден PPD {PPD_FILE}")

    subprocess.run(["/usr/sbin/cupsd"], check=True)
    if not wait_for_cups():
        raise SystemExit("cupsd не запустился")

    # Печать в файл: так мы забираем готовый поток вместо отправки в устройство.
    subprocess.run(
        ["lpadmin", "-p", QUEUE, "-v", f"file://{OUTPUT_FILE}", "-P", PPD_FILE, "-E"],
        check=True, capture_output=True)
    subprocess.run(["cupsaccept", QUEUE], check=False)
    subprocess.run(["cupsenable", QUEUE], check=False)
    log(f"очередь {QUEUE} готова, модель {MODEL}")


def parse_options(raw):
    """Строка параметров CUPS -> список аргументов для lp."""
    arguments = []
    copies = None
    try:
        tokens = shlex.split(raw or "")
    except ValueError:
        tokens = (raw or "").split()

    for token in tokens:
        if "=" not in token:
            continue
        key, value = token.split("=", 1)
        if key == "copies":
            if value.isdigit() and 1 <= int(value) <= 99:
                copies = value
        elif key in ALLOWED_OPTIONS:
            arguments += ["-o", f"{key}={value}"]
    return arguments, copies


def wait_for_queue_empty(timeout=180.0):
    deadline = time.time() + timeout
    while time.time() < deadline:
        result = subprocess.run(["lpstat", "-o"], capture_output=True, text=True)
        if not result.stdout.strip():
            return True
        time.sleep(0.2)
    return False


def cups_error_tail(lines=15):
    try:
        with open("/var/log/cups/error_log", "r", errors="replace") as handle:
            return "".join(handle.readlines()[-lines:])
    except OSError:
        return ""


def convert(pdf_bytes, options):
    with _lock:
        with open(INPUT_FILE, "wb") as handle:
            handle.write(pdf_bytes)
        with open(OUTPUT_FILE, "wb"):
            pass
        os.chmod(OUTPUT_FILE, 0o666)

        arguments, copies = parse_options(options)
        command = ["lp", "-d", QUEUE, "-s"]
        if copies:
            command += ["-n", copies]
        command += arguments + [INPUT_FILE]

        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(result.stderr.strip() or "lp завершился с ошибкой")

        if not wait_for_queue_empty():
            raise RuntimeError("задание не завершилось за отведённое время")

        with open(OUTPUT_FILE, "rb") as handle:
            data = handle.read()
        if not data:
            raise RuntimeError("фильтр не выдал данных\n" + cups_error_tail())
        return data


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        log(fmt % args)

    def _send(self, code, body, content_type="text/plain; charset=utf-8"):
        payload = body if isinstance(body, bytes) else body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        if self.path.startswith("/health"):
            self._send(200, "ok")
        else:
            self._send(404, "not found")

    def do_POST(self):
        if not self.path.startswith("/print"):
            self._send(404, "not found")
            return

        if TOKEN and self.headers.get("X-Print-Token", "") != TOKEN:
            log("отказ: неверный токен")
            self._send(403, "неверный токен доступа")
            return

        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            self._send(400, "пустое задание")
            return

        pdf_bytes = self.rfile.read(length)
        options = self.headers.get("X-Print-Options", "")

        try:
            data = convert(pdf_bytes, options)
        except Exception as error:                      # noqa: BLE001 - отдаём текст клиенту
            log(f"ошибка: {error}")
            self._send(500, str(error))
            return

        log(f"готово: {len(data)} байт")
        self._send(200, data, "application/octet-stream")


class ThreadedServer(http.server.ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    start_cups()
    server = ThreadedServer(("0.0.0.0", PORT), Handler)
    log(f"слушаю порт {PORT}")
    server.serve_forever()


if __name__ == "__main__":
    main()
